
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <GL/glut.h>

#include <sys/time.h>

#include <ode/ode.h>
#include <ode/odecpp.h>
#include <ode/odecpp_collision.h>

#include <vector>
#include <iostream>
using namespace std;

#ifndef M_PI
#define M_PI 3.14159265
#endif

static GLint T0 = 0;
static GLint Frames = 0;
static GLint autoexit = 0;

static dWorld* world = 0;
static dSpace* space = 0;
static dJointGroup* contact_group = 0;

/** A test object. Simple colliding sphere.
 */
class Object {
public:
  Object();
  
  dBody* getBody() const { return __body; }
  void setBody(dBody* body) {
    __body = body;
    body->setData(this);
  }
  
  dGeom* getGeom() const { return __geom; }
  void setGeom(dGeom* geom) {
    __geom = geom;
    geom->setData(this);
  }
  
  void setColor(float r, float g, float b) {
    __color[0] = r;
    __color[1] = g;
    __color[2] = b;
  }
  
  void setRadius(float radius) { __radius = radius; }
  
  void draw();
  
private:
  dBody* __body;
  dGeom* __geom;
  float  __radius;
  float  __color[3];
};

Object::Object()
  : __body(0),
    __geom(0),
    __radius(1)
{}

void Object::draw() {
  glPushMatrix();
  
  const dReal* p = getBody()->getPosition();
  glTranslatef(p[0], p[1], p[2]);
  
  glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, __color);
  if(__radius < 1) {
    glutSolidSphere(__radius, 10, 10);
  } else {
    glutSolidSphere(__radius, 50, 50);
  }
  
  glPopMatrix();
}


static vector<Object*> objects;
static Object* object1;
static Object* object2;
static Object* object3;
static Object* object4;

static GLfloat view_rotx = 20.0, view_roty = 30.0, view_rotz = 0.0;

static void
draw(void)
{
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
  
  glPushMatrix();
    glRotatef(view_rotx, 1.0, 0.0, 0.0);
    glRotatef(view_roty, 0.0, 1.0, 0.0);
    glRotatef(view_rotz, 0.0, 0.0, 1.0);
    
    for(unsigned int i=0; i<objects.size(); ++i) {
      objects[i]->draw();
    }
    
  glPopMatrix();
  
  glutSwapBuffers();
  
  Frames++;
  {
     GLint t = glutGet(GLUT_ELAPSED_TIME);
     if (t - T0 >= 5000) {
        GLfloat seconds = (t - T0) / 1000.0;
        GLfloat fps = Frames / seconds;
        printf("%d frames in %6.3f seconds = %6.3f FPS\n", Frames, seconds, fps);
        T0 = t;
        Frames = 0;
        if ((t >= 999.0 * autoexit) && (autoexit))
           exit(0);
     }
  }
}

static const int MAX_CONTACTS = 256;
static dContactGeom contacts[MAX_CONTACTS];
static int num_contacts = 0;

static void near_callback(void* data, dGeomID o1, dGeomID o2) {
  if(dGeomIsSpace(o1) || dGeomIsSpace(o2)) {
    dSpaceCollide2(o1, o2, data, &near_callback);
    // XXX...
//     if(dGeomIsSpace(o1)) {
//       dSpaceCollide(o1, &near_callback);
//     }
//     if(dGeomIsSpace(o2)) {
//       dSpaceCollide(o2, data, &near_callback);
//     }
  } else {
    num_contacts += dCollide(o1, o2, MAX_CONTACTS, contacts + num_contacts, 0);
  }
}

static timeval last_time;
static bool first_frame = true;

static void
idle(void)
{
  /* BEGIN> Simple Timing */
  timeval curr_time;
  gettimeofday(&curr_time, 0);
  float delta;
  if(first_frame) {
    delta = 0.01;
  } else {
    timeval delta_time;
    delta_time.tv_sec = curr_time.tv_sec - last_time.tv_sec;
    if(curr_time.tv_usec > last_time.tv_usec) {
      delta_time.tv_usec = curr_time.tv_usec - last_time.tv_usec;
    } else {
      delta_time.tv_usec = 1000000 + curr_time.tv_usec - last_time.tv_usec;
      --delta_time.tv_sec;
    }
    delta = float(delta_time.tv_sec) + float(delta_time.tv_usec) * 0.000001;
  }
  first_frame = false;
  last_time = curr_time;
  /* END< Simple Timing */
  
  /* BEGIN> Collision Detection */
  /* detect collisions */
  num_contacts = 0;
  space->collide(0, near_callback);
  
  contact_group = new dJointGroup();
  for(int i=0; i<num_contacts; ++i) {
    /* create dContact structure */
    dContact contact;
    contact.surface.mode = dContactBounce;
    contact.surface.bounce = 0.4;
    contact.surface.bounce_vel = 10;
    contact.surface.mu = 0;
    contact.geom = contacts[i];
    
    /* create contact joint */
    dContactJoint* contact_joint = new dContactJoint(world->id(), contact_group->id(), &contact);
    Object* obj1 = reinterpret_cast<Object*>(dGeomGetData(contacts[i].g1));
    Object* obj2 = reinterpret_cast<Object*>(dGeomGetData(contacts[i].g2));
    contact_joint->attach(obj1->getBody()->id(), obj2->getBody()->id());
  }
  /* END< */
  
  /* BEGIN> Apply forces */
  const dReal* p;
  float factor = -0.001;
  float f[3];
  for(unsigned int i=0; i<objects.size(); ++i) {
    /* gravity to center of blue sphere */
    p = objects[i]->getBody()->getPosition();
    f[0]=p[0]*factor; f[1]=(p[1]+20)*factor; f[2]=p[2]*factor;
    objects[i]->getBody()->addForce(f[0], f[1], f[2]);
  }
  
  /* END< Apply forces */
  
  /* BEGIN> Simulate */
  world->step(delta);
  delete contact_group;
  contact_group = 0;
  /* END< Simulate */
  
  glutPostRedisplay();
}

/* change view angle, exit upon ESC */
/* ARGSUSED1 */
static void
key(unsigned char k, int x, int y)
{
  switch (k) {
  case 'z':
    view_rotz += 5.0;
    break;
  case 'Z':
    view_rotz -= 5.0;
    break;
  case 27:  /* Escape */
    exit(0);
    break;
  default:
    return;
  }
  glutPostRedisplay();
}

/* change view angle */
/* ARGSUSED1 */
static void
special(int k, int x, int y)
{
  switch (k) {
  case GLUT_KEY_UP:
    view_rotx += 5.0;
    break;
  case GLUT_KEY_DOWN:
    view_rotx -= 5.0;
    break;
  case GLUT_KEY_LEFT:
    view_roty += 5.0;
    break;
  case GLUT_KEY_RIGHT:
    view_roty -= 5.0;
    break;
  default:
    return;
  }
  glutPostRedisplay();
}

/* new window size or exposure */
static void
reshape(int width, int height)
{
  GLfloat h = (GLfloat) height / (GLfloat) width;

  glViewport(0, 0, (GLint) width, (GLint) height);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  glFrustum(-1.0, 1.0, -h, h, 5.0, 60.0);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  glTranslatef(0.0, 0.0, -40.0);
}

static void
init(int argc, char *argv[]) {
  static GLfloat pos[4] = {5.0, 5.0, 10.0, 0.0};
  glLightfv(GL_LIGHT0, GL_POSITION, pos);
  glEnable(GL_CULL_FACE);
  glEnable(GL_LIGHTING);
  glEnable(GL_LIGHT0);
  glEnable(GL_DEPTH_TEST);
  
  glEnable(GL_NORMALIZE);
  
  world = new dWorld();
  space = new dHashSpace(0);
  
  dMass mass;
  dBody* body = 0;
  
  const int N = 100;
  dBody* bodies[N];
  for(unsigned int i=0; i<N; ++i) {
    object4 = new Object();
    objects.push_back(object4);
    body = new dBody();
    body->create(*world);
    object4->setBody(body);
    object4->getBody()->setPosition(0, 1.0 + 0.5 * i, 0);
    object4->getBody()->setLinearVel(i == 0 ? -1.5 : 0, i == 10 ? 2.0 : 0, i == 5 ? 1.2 : 0);
    object4->setGeom(new dSphere(space->id(), 0.2));
    object4->getGeom()->setBody(object4->getBody()->id());
    object4->setColor(1,float(i) / N,0);
    object4->setRadius(0.2);
    dMassSetSphere(&mass, 0.5, 0.2);
    object4->getBody()->setMass(&mass);
    
    bodies[i] = object4->getBody();
    object4->getBody()->setGravityMode(i != 1);
  }
  dJointGroup* group = new dJointGroup();
  for(unsigned int i=0; i<N-1; ++i) {
    dBallJoint* joint = new dBallJoint(world->id(), group->id());
    joint->attach(bodies[i]->id(), bodies[i+1]->id());
    joint->setAnchor(0, 1.0 + 0.5 * i + 0.25, 0);
  }

  object1 = new Object();
  objects.push_back(object1);
  body = new dBody();
  body->create(*world);
  object1->setBody(body);
  object1->getBody()->setPosition(12.0, 1.0, 0);
  object1->getBody()->setLinearVel(-3.0, 0, 0);
  object1->setGeom(new dSphere(space->id(), 1));
  object1->getGeom()->setBody(object1->getBody()->id());
  object1->setColor(0,1,0);
  object1->setRadius(1);
  dMassSetSphere(&mass, 1.0, 1.0);
  object1->getBody()->setMass(&mass);

  object2 = new Object();
  objects.push_back(object2);
  body = new dBody();
  body->create(*world);
  object2->setBody(body);
  object2->getBody()->setPosition(-12.0, 1.0, 0);
  object2->getBody()->setLinearVel(3.0, 0, 0);
  object2->setGeom(new dSphere(space->id(), 1));
  object2->getGeom()->setBody(object2->getBody()->id());
  object2->setColor(0,1,0);
  object2->setRadius(1);
  dMassSetSphere(&mass, 1.0, 1.0);
  object2->getBody()->setMass(&mass);

  object3 = new Object();
  objects.push_back(object3);
  body = new dBody();
  body->create(*world);
  object3->setBody(body);
  object3->getBody()->setPosition(0, -20, 0);
  object3->getBody()->setLinearVel(0, 0, 0);
  object3->setGeom(new dSphere(space->id(), 18));
  object3->getGeom()->setBody(object3->getBody()->id());
  object3->setColor(0,0,1);
  object3->setRadius(18);
  dMassSetSphere(&mass, 100, 18);
  object3->getBody()->setMass(&mass);
}

static void 
visible(int vis)
{
  if(vis == GLUT_VISIBLE) {
    glutIdleFunc(idle);
  } else {
    glutIdleFunc(0);
  }
}

int main(int argc, char *argv[]) {
  glutInit(&argc, argv);
  glutInitDisplayMode(GLUT_RGB | GLUT_DEPTH | GLUT_DOUBLE);
  
  glutInitWindowPosition(0, 0);
  glutInitWindowSize(300, 300);
  glutCreateWindow("ODE Test");
  init(argc, argv);
  
  glutDisplayFunc(draw);
  glutReshapeFunc(reshape);
  glutKeyboardFunc(key);
  glutSpecialFunc(special);
  glutVisibilityFunc(visible);
  
  glutMainLoop();
  return 0;
}
