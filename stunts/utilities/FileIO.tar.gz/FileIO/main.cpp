#include "main.h"

struct TestStruct
{
	int val1;
	float val2;
	char string1[5];

	float* array1;
	unsigned int array1_size;
};


int main()
{
	FileIO fio;

	bool bRval;

	//delete file
	bRval = fio.Open("testfile.dat", FILE_WRITE_MODE);
	fio.GotoBegin();
	fio.PushHeader("bitch!");

	bRval = fio.Open("testfile.dat", FILE_READ_MODE);
	if (!fio.GotoHeader("bitch!"))
		return 1;

	//welcome message
	cout << "FileIO class test" << endl << endl;

	//initial state
	cout << "initial state:"	<< endl;
	cout << "fio.FileName() = "	<< !(fio.FileName() == NULL)	<< endl;
	cout << "fio.GotoNext() = "	<< fio.GotoNext()	<< endl;
	cout << "fio.IsOpen() = "	<< fio.IsOpen()		<< endl;
	cout << "fio.Mode() = "		<< fio.Mode()		<< endl;
	cout << "fio.Size() = "		<< fio.Size()		<< endl;
	cout << "fio.PopByte() = "	<< !(fio.PopByte() == 0)	<< endl<< endl;


	//open file to write
	bRval = fio.Open("testfile.dat", FILE_RW_MODE);
	cout << "fio.Open = "		<< bRval		<< endl;
	if (fio.FileName())
		cout << "fio.FileName() = "	<< fio.FileName() 	<< endl;
	cout << "fio.IsOpen() = "	<< fio.IsOpen()		<< endl;
	cout << "fio.Mode() = "		<< fio.Mode()		<< endl;
	cout << "fio.Size() = "		<< fio.Size()		<< endl<< endl;


	//write a byte
	bRval = fio.PushByte(100);
	bRval = fio.PushByte(100);
	bRval = fio.PushByte(100);
	cout << "fio.PushByte = "		<< bRval		<< endl;
	cout << "fio.Size() = "		<< fio.Size()		<< endl<< endl;


	//read a byte
	cout << "fio.PopByte = "		<< (int)fio.PopByte()		<< endl<< endl;


	//goto begin
	bRval = fio.GotoBegin();
	cout << "fio.GotoBegin = "		<< bRval		<< endl<< endl;


	//read a byte again
	cout << "fio.PopByte = "		<< (int)fio.PopByte()		<< endl<< endl;

	//read a byte again
	cout << "fio.PopByte = "		<< (int)fio.PopByte()		<< endl<< endl;

	//read a byte again
	cout << "fio.PopByte = "		<< (int)fio.PopByte()		<< endl<< endl;


	//get record size
	cout << "fio.PopRecordSize = "		<< (int)fio.PopRecordSize()		<< endl<< endl;


	//get size
	cout << "fio.Size() = "		<< fio.Size()		<< endl<< endl;

	//write a record
	char* rec1 = "Testtext";
	bRval = fio.PushRecord(rec1, strlen(rec1));
	cout << "fio.PushRecord = "		<< bRval		<< endl;
	cout << "fio.Size() = "		<< fio.Size()		<< endl<< endl;


	//goto begin
	bRval = fio.GotoBegin();
	cout << "fio.GotoBegin = "		<< bRval		<< endl<< endl;


	//get next record
	while(fio.Mode() != RECORD_MODE)
	{
		bRval=fio.GotoNext();
		if (!bRval)
		{
			cout << "no record" << endl;
			break;
		}
	}

	if (fio.Mode() == RECORD_MODE)
		cout << "record found" << endl;


	//read from record
	int rec2Size = fio.PopRecordSize();
	cout << "fio.PopRecordSize = "		<< rec2Size		<< endl;

	char* rec2 = new char[rec2Size + 1];
	
	bRval = fio.PopRecord(rec2);
	cout << "fio.PopRecord = "		<< bRval		<< endl;

	rec2[rec2Size] = 0;
	cout << "rec2 = "		<< rec2		<< endl;

	if (rec2)
		delete rec2;



	//prepare test struct
	TestStruct ts1;
	memset(&ts1, 0, sizeof(TestStruct));
	ts1.val1 = 5;
	ts1.val2 = 0.4455f;
	ts1.array1_size = 3;
	ts1.array1 = new float[ts1.array1_size];
	ts1.array1[0] = 1.0f;
	ts1.array1[1] = 1.0f;
	ts1.array1[2] = 1.0f;
	strcpy(ts1.string1,"abcd");

	//write header bytes
	fio.PushHeader("MyHeader1");

	//write structure and array
	cout << "ts1.array1_size: "  << ts1.array1_size << endl;
	cout << "ts1.string1: "  << ts1.string1 << endl;
	cout << "ts1.val1: "  << ts1.val1 << endl;
	cout << "ts1.val2: "  << ts1.val2 << endl;
	cout << "ts1.array1: "  << !(ts1.array1==NULL) << endl << endl;

	fio.PushRecord(&ts1, sizeof(TestStruct));
	fio.PushRecord(ts1.array1, ts1.array1_size * sizeof(float));

	delete ts1.array1;

	//goto begin
	bRval = fio.GotoBegin();
	cout << "fio.GotoBegin = "		<< bRval		<< endl<< endl;

	//goto header
	if (!fio.GotoHeader("MyHeader1"))
		return 1;


	//reset structure
	memset(&ts1, 0, sizeof(TestStruct));
	cout << "ts1.array1_size: "  << ts1.array1_size << endl;
	cout << "ts1.string1: "  << ts1.string1 << endl;
	cout << "ts1.val1: "  << ts1.val1 << endl;
	cout << "ts1.val2: "  << ts1.val2 << endl;
	cout << "ts1.array1: "  << !(ts1.array1==NULL) << endl << endl;


	//read structure
	fio.PopRecord(&ts1);
	cout << "ts1.array1_size: "  << ts1.array1_size << endl;
	cout << "ts1.string1: "  << ts1.string1 << endl;
	cout << "ts1.val1: "  << ts1.val1 << endl;
	cout << "ts1.val2: "  << ts1.val2 << endl;
	cout << "ts1.array1: "  << !(ts1.array1==NULL) << endl << endl;


	//read array
	ts1.array1 = new float[ts1.array1_size];
	bRval = fio.PopRecord(ts1.array1);

	if (bRval)
	{
		cout << "array:" << endl;
		for (int c=0; c<ts1.array1_size;c++)
			cout << "ts1.array1[" << c << "] = "<< ts1.array1[c] << endl;
	}
	else
		cout << "some error..." << endl << endl;


	//end message
	cout << "end FileIO class test" << endl << endl;

	char input;
	cin >> input;

	return 0;
}
