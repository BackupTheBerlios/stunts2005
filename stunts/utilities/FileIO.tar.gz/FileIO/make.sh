#! /bin/sh
g++ -o main.bin FileIO.cpp main.cpp 
