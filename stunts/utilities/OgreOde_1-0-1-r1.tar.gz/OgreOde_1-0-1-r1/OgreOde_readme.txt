Readme for OgreOde
==================

Brief build instructions follow for OgreOde 1.0.0 Final Edition. 
Consider this version of OgreOde deprecated. A new and exciting development
is on the horizon. Watch this space.

1) You should have extracted this archive to $OGRE_TOP/OgreOde, where $OGRE_TOP
   is the root directory of your Ogre installation, usually named 'ogrenew'.
   All file paths in this build environment should be relative and all the DLLs
   and executables should get sent to the correct place upon building.

   This version of OgreOde is only supported when compiled against version 
   1.0.0 final of the Ogre library, but see step 4 which requires you to make
   some changes to the core Ogre libraries in order for it to be compatible 
   with OgreOde.

2) A modified version of ODE, including OPCODE, is included in the ode-0.5
   directory. No other versions of ODE are officially supported, but they might
   work. See the OgreOde_readme.txt file in that directory for further details, 
   especially regarding some optional components which are already included 
   in the modified version. 

   If you are using MSVC 7.1 then the supplied solution should build
   this version of ODE as part of a batch build. If not then you will need to
   compile ODE yourself according to it's instructions

   ODE is available from http://www.ode.org/

3) Version 2.3.3 of TinyXml is included in the tinyxml directory. See
   the OgreOde_readme.txt file in that directory for further details, especially 
   regarding the changes to the MSVC projects which are required for the library 
   to be compatible with OgreOde. 

   If you are using MSVC 7.1 then the supplied solution should build a compatible 
   version of TinyXml as part of a batch build. If not then you will need to compile 
   it yourself as per it's instructions. 

   TinyXml is only required by the OgreOde_Prefabs library, if you are not using 
   this (i.e. you don't need the supplied Vehicle and Ragdoll functionality) then 
   you do not need to build TinyXml.

   TinyXml is available from http://www.grinninglizard.com/tinyxml/

4) 
   a) In order for the Ragdoll functionality to perform correctly you are required
      to make some simple changes to the core Ogre libraries. Please see the file
      OgreOde_OGRE.txt for details. 

      If you do not wish to modify your copy of Ogre you can simply remove the 
      Ragdoll functionality from the OgreOde_Prefab project, or just not compile 
      the prefabricated objects project at all. Obviously this will mean you will
      not have access to Ragdolls or Vehicles.

   b) To prevent a crash when exiting the Landscape demo you need to make a simple
      change to the Terrain scene manager. This change is also detailed in the
      file OgreOde_OGRE.txt

   Once you have made these changes you will need to rebuild the Ogre libraries 
   before building OgreOde.

5) Use the solution $OGRE_TOP/OgreOde_1-0-1/scripts/VC7.1 to build the core OgreOde
   library, the OgreOde prefabricated objects library and the suite of demo
   programs with Microsoft Visual C++ .NET 7.1 2003. The DLLs and executables
   will be built to the $OGRE_TOP/Samples/Common/bin/Debug and Release
   directories.

   Simply open up that solution and perform a batch build.

6) There are some scripts which should build OgreOde under Linux in the scripts/Linux
   directory. They are provided courtesy of Pablo, please see the Readme in that directory
   for further details.

Contact "monster@beeb.net" for further details.

