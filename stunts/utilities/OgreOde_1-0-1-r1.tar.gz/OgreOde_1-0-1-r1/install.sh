#!/bin/sh

# modify ODE
echo "make sure that the OgreODE directory is in the ogrenew directory"
echo ""
echo "making and installing ode-0.5, (Press any key to continue, Ctrl-C to abord)"
read -n1


cd ode-0.5
patch -p1 < ../scripts/Linux/ode-plane2d-dterrain-linux.patch
echo OPCODE_DIRECTORY=OPCODE >> config/user-settings
make


#ask the user for the install path
installPathInclude="/usr/include/"
installPathLibs="/usr/lib/"


echo "Where should the header files be copied to?"
echo "[$installPathInclude]"
read -r installPathInclude

echo "Where should the library files be copied to?"
echo "[$installPathLibs]"
read -r installPathLibs


if test "${installPathInclude}" = ""; then
	installPathInclude="/usr/include/"
fi

if test "${installPathLibs}" = ""; then
	installPathLibs="/usr/lib/"
fi


echo "header files: $installPathInclude"
echo "libraries: $installPathLibs"

echo "Press any key to continue, Ctrl-C to abord"
read -n1

#copy files
cp -rf include/ode/ $installPathInclude
cp lib/libode.a $installPathLibs

ldconfig
cd ..


## patch and automake
echo "making and installing OgreODE, (Press any key to continue, Ctrl-C to abord)"
read -n1

patch -p1 < scripts/Linux/ogreode-changes.patch
patch -p1 < scripts/Linux/ogreode-automake.patch
sh bootstrap && ./configure
make
