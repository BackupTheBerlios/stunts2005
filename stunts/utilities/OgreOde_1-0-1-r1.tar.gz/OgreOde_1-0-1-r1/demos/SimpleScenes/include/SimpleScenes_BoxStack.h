/*
SimpleScenes_BoxStack.h
----------------------
A reimplementation of the ODE box stacking (actually loads of different
objects) demo using Ogre and the OgreOde wrapper.
*/
#ifndef _SIMPLESCENES_BOXSTACK_H_
#define _SIMPLESCENES_BOXSTACK_H_

/*
The box stacking test extends the base test class
*/
class SimpleScenes_BoxStack:public SimpleScenes
{
public:
	// Standard constructor/destructor
	SimpleScenes_BoxStack(){}
	virtual ~SimpleScenes_BoxStack(){}

	// Return our name for the test application to display
	virtual const String& getName()
	{
		static String name = "Test Box Stack";
		return name;
	}

	// Return a description of the keys that the user can use in this test
	virtual const String& getKeys()
	{
		static String keys = "Z - Sphere, X - Box, C - Capsule";
		return keys;
	}

	// Handle the user's key presses
	virtual void frameEnded(Real time,InputReader* input)
	{
		// Do default key handling
		SimpleScenes::frameEnded(time,input);

		OgreOde::Body* body = 0;
	
		// Create random objects, that method will stop them being created too often
		if(input->isKeyDown(KC_Z)) body = createRandomObject(OgreOde::Geometry::Class_Sphere);
		else if(input->isKeyDown(KC_X)) body = createRandomObject(OgreOde::Geometry::Class_Box);
		else if(input->isKeyDown(KC_C)) body = createRandomObject(OgreOde::Geometry::Class_Capsule);
	}
};

#endif
