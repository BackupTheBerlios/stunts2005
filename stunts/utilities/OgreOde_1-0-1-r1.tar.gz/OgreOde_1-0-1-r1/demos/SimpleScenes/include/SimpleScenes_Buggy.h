/*
SimpleScenes_Buggy.h
-------------------
A reimplementation of the ODE test Buggy application using
the OgreOde wrapper for Ogre
*/
#ifndef _SIMPLESCENES_BUGGY_H_
#define _SIMPLESCENES_BUGGY_H_

#include "OgreOde_Prefab.h"

/*
Buggy test extends from the base test class
*/
class SimpleScenes_Buggy:public SimpleScenes
{
public:
	// Constructor also needs to create the scene
	SimpleScenes_Buggy()
	{
		// Create the vehicle from the config file
		vehicle = new OgreOde_Prefab::Vehicle("Subaru");
		vehicle->load("SimpleScenes.ogreode");
	
		// Move the vehicle
		vehicle->setPosition(Vector3(0,0.82898,0));

		// Initially (i.e. in the config file) it's rear wheel drive
		_drive = 'R';
		setInfoText("Rear wheel drive");

		// Create a box to jump over, the visual version
		Entity* entity = _mgr->createEntity("Jump", "Crate.mesh");
		entity->setNormaliseNormals(true);
		entity->setCastShadows(true);

		SceneNode* node = _mgr->getRootSceneNode()->createChildSceneNode(entity->getName());
		node->attachObject(entity);
		node->setPosition(Vector3(0,0.3,-5));
		node->setOrientation(Quaternion(Radian(0.4),Vector3(1,0,0)));
		node->setScale(0.3,0.1,0.4);

		// Create the physical version (just static geometry, it can't move so
		// it doesn't need a body) and keep track of it
		OgreOde::EntityInformer ei(entity,Matrix4::getScale(node->getScale()));
		_geoms.push_back(ei.createSingleStaticBox(_space));

		// The car is what we'll want to look at
		_last_node = vehicle->getSceneNode();
	}

	// Override the destructor since there's some special deleting to do
	virtual ~SimpleScenes_Buggy()
	{
		delete vehicle;

		// Destroy the jump manually since it's not associated with 
		// any body it won't get deleted automatically
		_mgr->destroySceneNode("Jump");
		_mgr->removeEntity("Jump");

		// Geometries and Joints will get deleted by the base class
	}

	// Return our name
	virtual const String& getName()
	{
		static String name = "Test Buggy";
		return name;
	}

	// Tell the user what keys they can use
	virtual const String& getKeys()
	{
		static String keys = "I/K - Accelerate/Brake, J/L - Turn, X - Change drive mode";
		return keys;
	}

	// Our special key handling
	virtual void frameEnded(Real time,InputReader* input)
	{
		// Do default processing
		SimpleScenes::frameEnded(time,input);

		// Tell the vehicle what digital inputs are being pressed; left, right, power and brake
		// There are equivalent methods for analogue controls, current you can't change gear so
		// you can't reverse!
		vehicle->setInputs(input->isKeyDown(KC_J),input->isKeyDown(KC_L),input->isKeyDown(KC_I),input->isKeyDown(KC_K));

		// Update the vehicle, you need to do this every time step
		vehicle->update(time);
		
		// Change the drive mode between front, rear and 4wd
		if((input->isKeyDown(KC_X))&&(_key_delay > SimpleScenes::KEY_DELAY))
		{
			switch(_drive)
			{
				// Switch from rear to front
				case 'R':
					_drive = 'F';

					vehicle->getWheel(0)->setPowerFactor(1);
					vehicle->getWheel(1)->setPowerFactor(1);
					vehicle->getWheel(2)->setPowerFactor(0);
					vehicle->getWheel(3)->setPowerFactor(0);

					setInfoText("Front wheel drive");
				break;

				// Switch from front to all
				case 'F':
					_drive = '4';

					vehicle->getWheel(0)->setPowerFactor(0.6);
					vehicle->getWheel(1)->setPowerFactor(0.6);
					vehicle->getWheel(2)->setPowerFactor(0.4);
					vehicle->getWheel(3)->setPowerFactor(0.4);

					setInfoText("All wheel drive");
				break;

				// Switch from all to rear
				case '4':
					_drive = 'R';

					vehicle->getWheel(0)->setPowerFactor(0);
					vehicle->getWheel(1)->setPowerFactor(0);
					vehicle->getWheel(2)->setPowerFactor(1);
					vehicle->getWheel(3)->setPowerFactor(1);

					setInfoText("Rear wheel drive");
				break;
			}
			_key_delay = 0.0;
		}
	}

	// Override the collision callback to set our own parameters
	bool collision(OgreOde::Contact* contact)
	{
		// If the base class doesn't think the collision needs to 
		// happen then we won't do anything either
		if(!SimpleScenes::collision(contact)) return false;

		if(!OgreOde_Prefab::Vehicle::handleTyreCollision(contact))
		{
			// Set the floor to be a bit slippy
			contact->setCoulombFriction(12.0);
		}
		return true;
	}

protected:
	// Keep track of the things we need to delete manually or change according to user input
	OgreOde_Prefab::Vehicle *vehicle;
	char _drive;
};

#endif
