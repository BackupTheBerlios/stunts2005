/*
SimpleScenes.h
-------------
A basic framework class off which the specific scenes will be built.
Does some housekeeping of objects and so on, eventually functionality
similar to this will be built into OgreOde.
*/
#ifndef _SIMPLESCENES_H_
#define _SIMPLESCENES_H_

// We'll need the OgreOde definitions
#include "OgreOde_Core.h"

/*
The base Test class, is also able to listen for collisions and thus change the contact properties
*/
class SimpleScenes:public OgreOde::CollisionListener,public OgreOde::StepListener
{
public:
	static const Real KEY_DELAY;
	static const Real STEP_RATE;

	// Constructor/destructor
	SimpleScenes();
	virtual ~SimpleScenes();

	// Useful methods that will be handy for all tests
	OgreOde::Body* createRandomObject(OgreOde::Geometry::Class objectClass);
	void updateScene();
	const SceneNode* getLastNode(){return _last_node;}
	void setInfoText(const String& text);

	// The things we'll have to override in derived classes
	// Actual tests must provide a name but everything else can default
	virtual bool collision(OgreOde::Contact* contact);
	virtual const String& getKeys(){return StringUtil::BLANK;}
	virtual const String& getName() = 0;
	virtual void addForcesAndTorques(){}
	virtual void frameStarted(Real time,InputReader* input){}
	virtual void frameEnded(Real time,InputReader* input);

	// If we register this with a stepper it'll get told every time the world's about to be stepped
	bool preStep(Real time)
	{
		addForcesAndTorques();
		return true;
	}

protected:
	// Keep track of what created us
	SceneManager*		_mgr;
	OgreOde::World*		_world;
	OgreOde::Space*		_space;

	// Whatever the derived class sets this to will be what's looked at by the camera
	SceneNode*			_last_node;

	// Keep track of the things we create so we can 
	// delete them automatically when we switch scenes
	std::vector<OgreOde::Body*>		_bodies;
	std::vector<OgreOde::Geometry*> _geoms;
	std::vector<OgreOde::Joint*>	_joints;

	Real _key_delay;
};

#endif
