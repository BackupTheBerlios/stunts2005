/*
SimpleScenes_Zombie.h
---------------------
A demo Zombie shooting demo, showing ragdolls and ray intersections.
*/
#ifndef _SIMPLESCENES_ZOMBIE_H_
#define _SIMPLESCENES_ZOMBIE_H_

/*
The zombie demo extends the base test class
*/
class SimpleScenes_Zombie:public SimpleScenes
{
public:
	void createZombie()
	{
		_last_zombie = 0.0;

		 MeshPtr ptr = MeshManager::getSingleton().load("zombie_small.mesh",ResourceGroupManager::DEFAULT_RESOURCE_GROUP_NAME);
		_zombie_ragdoll = new OgreOde_Prefab::Ragdoll("zombie" + StringConverter::toString(_zombie_count),ptr,_mgr);
		_zombie_ragdoll->setCastShadows(true);
		
		// Add entity to the scene node
		_zombie_node = _mgr->getRootSceneNode()->createChildSceneNode(_zombie_ragdoll->getName());
		_zombie_node->attachObject(_zombie_ragdoll);
		_zombie_node->yaw(Degree(rand() % 360));
		_zombie_node->setPosition(0.0,0.0,0);

		_last_node = _zombie_node;

		_anim_state = _zombie_ragdoll->getAnimationState("Walk1");
		_anim_state->setEnabled(true);

		++_zombie_count;
	}

	// Constructor
	SimpleScenes_Zombie()
	{
	    _over = (Overlay*)OverlayManager::getSingleton().getByName("OgreOdeDemos/Target");    
		_over->show();

		_gun = _mgr->createEntity("gun","gun.mesh");
		_gun->setCastShadows(false);

		_gun_node = _mgr->getRootSceneNode()->createChildSceneNode("gun");
		_gun_node->attachObject(_gun);

		_camera = _mgr->getCamera("PlayerCam");

		_animation_speed = 1.0;
		_zombie_count = 0;
		createZombie();

		_shot_time = 0.0;
	}
	
	// Destructor
	virtual ~SimpleScenes_Zombie()
	{
		for(int i = 0;i < _zombie_count;++i)
		{
			_mgr->destroySceneNode("zombie" + StringConverter::toString(i));
			_mgr->removeEntity("zombie" + StringConverter::toString(i));
		}

		_over->hide();
		_mgr->destroySceneNode("gun");
		_mgr->removeEntity("gun");
	}

	// Return our name for the test application to display
	virtual const String& getName()
	{
		static String name = "Zombie Shooting Gallery";
		return name;
	}

	// Return a description of the keys that the user can use in this test
	virtual const String& getKeys()
	{
		static String keys = "X - Shoot";
		return keys;
	}

	virtual void frameStarted(Real time,InputReader* input)
	{
		_last_zombie += time;

		SimpleScenes::frameStarted(time,input);

		_gun_node->setOrientation(_camera->getOrientation());
		_gun_node->setPosition(_camera->getPosition() + (_camera->getOrientation() * Vector3(0.3,-0.15,-1.1)));

		if(!_zombie_ragdoll->isPhysical())
		{
			_anim_state->addTime(time * _animation_speed);
			_zombie_node->translate(_zombie_node->getOrientation() * (Vector3::UNIT_Z * time * 2.5));
		}
		_zombie_ragdoll->update();
	}

	// Handle the user's key presses
	virtual void frameEnded(Real time,InputReader* input)
	{
		_shot_time -= time;

		// Do default key handling
		SimpleScenes::frameEnded(time,input);	

		if(_zombie_ragdoll->isPhysical() && input->isKeyDown(KC_C))
		{
			_zombie_ragdoll->releasePhysicalControl();
			_anim_state->setEnabled(true);
		}

		if(_shot_time <= 0.0 && input->isKeyDown(KC_X))
		{
			Ray pickRay = _camera->getCameraToViewportRay(0.5,0.5);

			_shot_time = 0.5;

			if(!_zombie_ragdoll->isPhysical())
			{
				RaySceneQuery *mRayQuery = _mgr->createRayQuery(pickRay);
				RaySceneQueryResult& result = mRayQuery->execute();
				RaySceneQueryResult::iterator i = result.begin();
		
				bool found = false;
				while((!found) && (i != result.end()))
				{
					if((i->movable) && (i->movable->getName() == _zombie_ragdoll->getName())) found = true;
					++i;
				}

				if(found)
				{	
					_last_zombie = 5.0;
					_anim_state->setEnabled(false);

					_zombie_ragdoll->load("SimpleScenes.ogreode");//,"zombie");

					// Create the ragdoll
					_zombie_ragdoll->takePhysicalControl(_space,false);
					_zombie_ragdoll->setSelfCollisions(false);

					OgreOde::RayGeometry *ode_ray = new OgreOde::RayGeometry(1000.0,_space);
					ode_ray->setDefinition(pickRay.getOrigin(),pickRay.getDirection());
					Body *hit_body;
					Vector3 hit_point;
					if(_zombie_ragdoll->pick(ode_ray,hit_body,hit_point))
					{
						if(hit_body)
						{
							hit_body->addForceAt(pickRay.getDirection() * 250000,hit_point);
						}
					}
					else
					{
						_zombie_ragdoll->releasePhysicalControl();
						_anim_state->setEnabled(true);
					}
					delete ode_ray;
				}
			}
		}
		
		if(_last_zombie > 10.0)
		{
			if(!_zombie_ragdoll->isPhysical())
			{
				--_zombie_count;
				_mgr->destroySceneNode("zombie" + StringConverter::toString(_zombie_count));
				_mgr->removeEntity("zombie" + StringConverter::toString(_zombie_count));
			}
			else _zombie_ragdoll->turnToStone();

			createZombie();
		}
	}

protected:
	AnimationState* _anim_state;
	Real _animation_speed;
	SceneNode *_zombie_node;

	Entity *_gun;
	SceneNode *_gun_node;
	Camera* _camera;
	Overlay* _over;
	OgreOde_Prefab::Ragdoll *_zombie_ragdoll;

	Real _shot_time;

	Real _last_zombie;
	int _zombie_count;
};

#endif
