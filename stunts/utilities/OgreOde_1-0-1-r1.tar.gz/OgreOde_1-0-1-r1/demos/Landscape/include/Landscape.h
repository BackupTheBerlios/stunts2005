#include "ExampleApplication.h"
#include "OgreOde_Core.h"
#include "OgreOde_Prefab.h"

// #undef OGREODE_TERRAINGEOMETRY

class LandscapeFrameListener : public ExampleFrameListener
{
public:
	LandscapeFrameListener(RenderWindow* win, Camera* cam,Real time_step,OgreOde_Prefab::Vehicle* vehicle,Root* root);
	~LandscapeFrameListener();
    bool frameStarted(const FrameEvent& evt);

private:
	OgreOde::Stepper *_stepper;
	OgreOde_Prefab::Vehicle *_vehicle;
	RaySceneQuery *_ray_query;
};



class LandscapeApplication : public ExampleApplication
#ifdef OGREODE_TERRAINGEOMETRY
	,public OgreOde::TerrainGeometryHeightListener
#endif
	,public OgreOde::CollisionListener
{
public:
    LandscapeApplication();
    ~LandscapeApplication();

protected:

    virtual void chooseSceneManager(void);
	virtual void setupResources(void);
    virtual void createCamera(void);
    void createScene(void);
	void createFrameListener(void);

#ifdef OGREODE_TERRAINGEOMETRY
	virtual Real heightAt(const Vector3& position);
#endif

	virtual bool collision(OgreOde::Contact* contact);

	protected:
		OgreOde::World *_world;
		OgreOde_Prefab::Vehicle *_vehicle;
#ifdef OGREODE_TERRAINGEOMETRY
		OgreOde::TerrainGeometry *_terrain;
#else
		OgreOde::InfinitePlaneGeometry *_terrain;
#endif
		Real _time_step;
};

