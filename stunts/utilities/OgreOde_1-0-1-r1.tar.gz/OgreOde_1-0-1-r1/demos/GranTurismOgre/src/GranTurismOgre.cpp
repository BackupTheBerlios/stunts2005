#include "GranTurismOgre.h"

#if OGRE_PLATFORM == OGRE_PLATFORM_WIN32
#define WIN32_LEAN_AND_MEAN
#include "windows.h"

INT WINAPI WinMain( HINSTANCE hInst, HINSTANCE, LPSTR strCmdLine, INT )
#else
int main(int argc, char *argv[])
#endif
{
    GranTurismOgreApplication app;

    SET_TERM_HANDLER;
    
    try 
	{
		app.go();
    } 
	catch( Ogre::Exception& e )
	{
#if OGRE_PLATFORM == OGRE_PLATFORM_WIN32
        MessageBox( 0, e.getFullDescription().c_str(), "An exception has occured!", MB_OK | MB_ICONERROR | MB_TASKMODAL);
#else
        std::cerr << "An exception has occured: " << e.getFullDescription().c_str() << std::endl;
#endif
    }

    return 0;
}

GranTurismOgreFrameListener::GranTurismOgreFrameListener(RenderWindow* win, Camera* cam,Real time_step,OgreOde_Prefab::Vehicle *vehicle,Root *root) : ExampleFrameListener(win, cam)
{
	// Reduce move speed
    mMoveSpeed = 25;

	// Create something that will step the world automatically
	// _stepper = new OgreOde::ForwardFixedQuickStepper(time_step);
	_stepper = new OgreOde::ExactVariableQuickStepper(time_step);
	_stepper->setAutomatic(OgreOde::Stepper::AutoMode_PostFrame,root);

	_vehicle = vehicle;
}

GranTurismOgreFrameListener::~GranTurismOgreFrameListener()
{
	delete _stepper;
}

bool GranTurismOgreFrameListener::frameStarted(const FrameEvent& evt)
{
	Real time = evt.timeSinceLastFrame;

    bool ret = ExampleFrameListener::frameStarted(evt);

	if(mInputDevice->isKeyDown(KC_U)) _stepper->pause(false);
	if(mInputDevice->isKeyDown(KC_P)) _stepper->pause(true);

	if(!_stepper->isPaused())
	{
		_vehicle->setInputs(mInputDevice->isKeyDown(KC_J),mInputDevice->isKeyDown(KC_L),mInputDevice->isKeyDown(KC_I),mInputDevice->isKeyDown(KC_K));
		_vehicle->update(time);

		// Thanks to Ahmed!
		const Real followFactor = 0.2; 
		const Real camHeight = 2.0; 
		const Real camDistance = 7.0; 
		const Real camLookAhead = 8.0;

		Quaternion q = _vehicle->getSceneNode()->getOrientation(); 
		Vector3 toCam = _vehicle->getSceneNode()->getPosition(); 

		toCam.y += camHeight; 
		toCam.z -= camDistance * q.zAxis().z; 
		toCam.x -= camDistance * q.zAxis().x; 
	      
		mCamera->move( (toCam - mCamera->getPosition()) * followFactor ); 
		mCamera->lookAt(_vehicle->getSceneNode()->getPosition() + ((_vehicle->getSceneNode()->getOrientation() * Vector3::UNIT_Z) * camLookAhead));
	}
	return ret;
}

GranTurismOgreApplication::GranTurismOgreApplication()
{
	_world = 0;
	_time_step = 0.01;
	_vehicle = 0;
	_track = 0;
}

void GranTurismOgreApplication::chooseSceneManager(void)
{
    mSceneMgr = mRoot->getSceneManager( ST_GENERIC );
}

void GranTurismOgreApplication::setupResources(void)
{
	ExampleApplication::setupResources();
    ResourceGroupManager::getSingleton().addResourceLocation("../../../../OgreOde_1-0-1/demos/Media","FileSystem");
}

void GranTurismOgreApplication::createCamera(void)
{
    // Create the camera
    mCamera = mSceneMgr->createCamera("PlayerCam");

    mCamera->setPosition(Vector3(125,-14,8));
    mCamera->lookAt(mCamera->getPosition() + Vector3(0,0,1));
    mCamera->setNearClipDistance( 1 );
    mCamera->setFarClipDistance( 1000 );
}
   
// Just override the mandatory create scene method
void GranTurismOgreApplication::createScene(void)
{
    // Set ambient light
    mSceneMgr->setAmbientLight(ColourValue(0.5, 0.5, 0.5));
	mSceneMgr->setSkyBox(true,"GranTurismOgre/Skybox");

    // Create a light
    Light* l = mSceneMgr->createLight("MainLight");

	// Accept default settings: point light, white diffuse, just set position
    // NB I could attach the light to a SceneNode if I wanted it to move automatically with
    //  other objects, but I don't
    l->setPosition(20,800,50);
	l->setSpecularColour(1,0.9,0);

	l->setCastShadows(true);

	mSceneMgr->setShadowTechnique(SHADOWTYPE_STENCIL_MODULATIVE);
	mSceneMgr->setShadowColour(ColourValue(0.5,0.5,0.5));

	_world = new OgreOde::World(mSceneMgr);

	_world->setGravity(Vector3(0,-9.80665,0));
	_world->setCFM(10e-5);
	_world->setERP(0.8);
	_world->setAutoSleep(true);
	_world->setContactCorrectionVelocity(1.0);

	_vehicle = new OgreOde_Prefab::Vehicle("Subaru");
	_vehicle->load("SimpleScenes.ogreode");

	// Move the vehicle
	Vector3 v_pos = mCamera->getPosition() + (mCamera->getDirection() * 15.0);
	_vehicle->setPosition(v_pos);

	_world->setCollisionListener(this);

	SceneNode *track_node = mSceneMgr->getRootSceneNode()->createChildSceneNode("track");
	Entity *track_mesh = mSceneMgr->createEntity("track","RacingCircuit.mesh");
	track_node->attachObject(track_mesh);

	OgreOde::EntityInformer ei(track_mesh);
	_track = ei.createStaticTriangleMesh(_world->getDefaultSpace());
}

// Create new frame listener
void GranTurismOgreApplication::createFrameListener(void)
{
    mFrameListener= new GranTurismOgreFrameListener(mWindow, mCamera,_time_step,_vehicle,mRoot);
    mRoot->addFrameListener(mFrameListener);
}

bool GranTurismOgreApplication::collision(OgreOde::Contact* contact)
{
	if(!OgreOde_Prefab::Vehicle::handleTyreCollision(contact))
	{
		contact->setBouncyness(0.0);
		contact->setCoulombFriction(18.0);
	}
	return true;
}

GranTurismOgreApplication::~GranTurismOgreApplication()
{
	delete _track;
	delete _vehicle;
	delete _world;
}
