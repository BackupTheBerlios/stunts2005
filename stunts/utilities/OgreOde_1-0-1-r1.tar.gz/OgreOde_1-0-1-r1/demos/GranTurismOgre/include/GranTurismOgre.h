#include "ExampleApplication.h"
#include "OgreOde_Core.h"
#include "OgreOde_Prefab.h"

class GranTurismOgreFrameListener : public ExampleFrameListener
{
public:
	GranTurismOgreFrameListener(RenderWindow* win, Camera* cam,Real time_step,OgreOde_Prefab::Vehicle* vehicle,Root* root);
	~GranTurismOgreFrameListener();
    bool frameStarted(const FrameEvent& evt);

private:
	OgreOde::Stepper *_stepper;
	OgreOde_Prefab::Vehicle *_vehicle;
};



class GranTurismOgreApplication : public ExampleApplication,public OgreOde::CollisionListener
{
public:
    GranTurismOgreApplication();
    ~GranTurismOgreApplication();

protected:

    virtual void chooseSceneManager(void);
	virtual void setupResources(void);
    virtual void createCamera(void);
    void createScene(void);
	void createFrameListener(void);

	virtual bool collision(OgreOde::Contact* contact);

	protected:
		OgreOde::World *_world;
		OgreOde_Prefab::Vehicle *_vehicle;
		OgreOde::TriangleMeshGeometry *_track;

		Real _time_step;
};

