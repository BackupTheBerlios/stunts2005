#ifndef _OGREODEPREFABOBJECT_H_
#define _OGREODEPREFABOBJECT_H_

#include "OgreOde_Prefab.h"

namespace OgreOde_Prefab 
{
    class _OgreOdeExport_Prefab PrefabObject
    {
	public:
		PrefabObject(OgreOde_Prefab::ObjectType type):_type(type){}
		virtual ~PrefabObject(){}

		OgreOde_Prefab::ObjectType getObjectType(){return _type;}

	protected:
		OgreOde_Prefab::ObjectType _type;
	};
}

#endif

