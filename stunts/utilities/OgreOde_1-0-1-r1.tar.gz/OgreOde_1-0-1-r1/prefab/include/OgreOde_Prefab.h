#ifndef _OGREODE_PREFAB_H_
#define _OGREODE_PREFAB_H_

using namespace Ogre;
using namespace OgreOde;

#include "OgreOde_Core.h"

namespace OgreOde_Prefab
{
    #if OGRE_PLATFORM == OGRE_PLATFORM_WIN32
    #   if defined( OGREODEEXPORT_PREFAB )
    #       define _OgreOdeExport_Prefab __declspec( dllexport )
    #   else
    #       define _OgreOdeExport_Prefab __declspec( dllimport )
    #   endif
    #else
    #   define _OgreOdeExport_Prefab
    #endif

	enum ObjectType
	{
		ObjectType_Vehicle,
		ObjectType_Wheel,
		ObjectType_Ragdoll
	};
}

#include "OgreOdePrefabObject.h"
#include "OgreOdeVehicle.h"
#include "OgreOdeRagdoll.h"

#endif
