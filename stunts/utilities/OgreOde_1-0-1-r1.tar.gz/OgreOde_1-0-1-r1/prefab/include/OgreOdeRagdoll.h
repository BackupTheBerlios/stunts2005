#ifndef _OGREODERAGDOLL_H_
#define _OGREODERAGDOLL_H_

#include "OgreOde_Prefab.h"

#include <map>

namespace OgreOde_Prefab 
{
	class _OgreOdeExport_Prefab Ragdoll : public PrefabObject, public Entity, public CollisionListener
    {
	public:
		class _OgreOdeExport_Prefab PhysicalBone
		{
		public:
			PhysicalBone();
			~PhysicalBone();

		public:
			Body								*_body;
			Geometry							*_geometry;
			Vector3								_original_position;
			Quaternion							_original_orientation;
			Bone								*_bone;
			Ragdoll::PhysicalBone				*_parent_bone;
			std::vector<Ragdoll::PhysicalBone*>	_child_bones;
			Joint								*_joint;
			AngularMotorJoint					*_motor;
		};

		class _OgreOdeExport_Prefab BoneSettings
		{
		public:
			enum Collapse
			{
				Collapse_None,
				Collapse_Up,
				Collapse_Down
			};

		public:
			BoneSettings();
			~BoneSettings();

		public:
			Geometry::Class		_geometry_class;
			Joint::Type			_joint_type;
			Vector3				_primary_axis;
			Vector3				_secondary_axis;
			Collapse			_collapse;
			Real				_mass;
			Real				_radius;
			Real				_primary_histop,_primary_lostop,_secondary_histop,_secondary_lostop;
			Real				_linear_damping,_angular_damping;
		};

	public:
		Ragdoll(const String& name, MeshPtr& ptr, SceneManager* creator); 

		void setDefaultBoneSettings(const Ragdoll::BoneSettings &settings);
		const Ragdoll::BoneSettings &getDefaultBoneSettings(){return _default_bone_settings;}
		
		void setBoneSettings(const String& bone_name,const Ragdoll::BoneSettings &settings);
		void setSelfCollisions(bool collide);

		void takePhysicalControl(Space* space,bool static_geometry = false);
		void turnToStone();
		void releasePhysicalControl();

		bool isPhysical(){return _is_physical;}
		bool isStatic(){return _is_static;}

		~Ragdoll();

		void update();
		void load(const String &filename,const String &ragdoll_name = StringUtil::BLANK);

        virtual const AxisAlignedBox& getBoundingBox(void) const;

		bool pick(RayGeometry *ray,Body* &body,Vector3 &position);
		bool collision(Contact* contact);

	protected:
		void createBoneBody(Bone *bone,Ragdoll::PhysicalBone *parent,bool static_geometry);
		void updatePhysicalBone(Ragdoll::PhysicalBone *physical_bone,const Matrix4 &this_trans,const Matrix4 &base_trans);

		void turnToStone(Ragdoll::PhysicalBone* bone);
		void releasePhysicalControl(Ragdoll::PhysicalBone* bone);

		void pick(Ragdoll::PhysicalBone *bone,RayGeometry *ray);

		void parseSettings(Ragdoll::BoneSettings &settings,const void *tag);

		std::vector<Ragdoll::PhysicalBone*> _root_bones;
		Ragdoll::BoneSettings _default_bone_settings;
		std::map<String,Ragdoll::BoneSettings> _bone_settings;
		Matrix4 _node_trans,_node_trans_inv;
		Quaternion _node_orient;
		Vector3 _node_posn;

		std::vector<std::pair<Body*,Vector3> > _hit_list;

		EntityInformer *_ei;
		SimpleSpace *_space;
		JointGroup *_joint_group;
		Mesh *_mesh;
		bool _is_static;
		bool _is_physical;
	};
}

#endif
