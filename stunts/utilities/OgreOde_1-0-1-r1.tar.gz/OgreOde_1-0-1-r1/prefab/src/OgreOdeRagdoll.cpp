#include "OgreOdeWorld.h"
#include "OgreOdeBody.h"
#include "OgreOdeJoint.h"
#include "OgreOdeGeometry.h"
#include "OgreOdeSpace.h"
#include "OgreOdeRagdoll.h"
#include "OgreOdeEntityInformer.h"
#include "OgreOdeMass.h"
#include "OgreOdeUtility.h"

#include "OgreOdeRagdoll.h"

#include <tinyxml.h>

using namespace OgreOde_Prefab;

Ragdoll::PhysicalBone::PhysicalBone()
{
	_body = 0;
	_geometry = 0;
	_original_position = Vector3::ZERO;
	_original_orientation = Quaternion::IDENTITY;
	_bone = 0;
	_parent_bone = 0;
	_joint = 0;
	_motor = 0;
}

Ragdoll::PhysicalBone::~PhysicalBone()
{
	delete _joint;
	delete _geometry;
	delete _body;
	delete _motor;

	for(std::vector<Ragdoll::PhysicalBone*>::iterator i = _child_bones.begin();i != _child_bones.end();++i) delete (*i);
}

Ragdoll::BoneSettings::BoneSettings()
{
	_geometry_class		= Geometry::Class_Capsule;
	_joint_type			= Joint::Type_BallJoint;
	_primary_axis		= Vector3::UNIT_X;
	_secondary_axis		= Vector3::UNIT_Y;
	_collapse			= Ragdoll::BoneSettings::Collapse_None;
	_mass				= 1.0;
	_radius				= 1.0;
	_primary_histop		= OgreOde::Utility::Infinity;
	_primary_lostop		= -OgreOde::Utility::Infinity;
	_secondary_histop	= OgreOde::Utility::Infinity;
	_secondary_lostop	= -OgreOde::Utility::Infinity;
	_linear_damping     = 0.0;
	_angular_damping    = 0.0;
}

Ragdoll::BoneSettings::~BoneSettings()
{
}

Ragdoll::Ragdoll(const String& name, MeshPtr& ptr, SceneManager* creator):
	Entity(name,ptr,creator),
	PrefabObject(OgreOde_Prefab::ObjectType_Ragdoll) 
{
	creator->addEntity(this);

	setDefaultBoneSettings(Ragdoll::BoneSettings());
	_ei = 0;
	_joint_group = 0;
	_is_static = true;
	_mesh = 0;
	_space = 0;
	_is_physical = false;

	_node_trans = Matrix4::IDENTITY;
	_node_trans_inv = _node_trans.inverse();
	_node_orient = Quaternion::IDENTITY;
	_node_posn = Vector3::ZERO;
}

void Ragdoll::setDefaultBoneSettings(const Ragdoll::BoneSettings &settings)
{
	_default_bone_settings = settings;
}

void Ragdoll::setBoneSettings(const String& bone_name,const Ragdoll::BoneSettings &settings)
{
	_bone_settings.insert(std::pair<String,Ragdoll::BoneSettings>(bone_name,settings));
}

void Ragdoll::setSelfCollisions(bool collide)
{
	_space->setInternalCollisions(collide);
}

void Ragdoll::takePhysicalControl(Space* space,bool static_geometry)
{
	// Cache node transformations
	_node_posn = mParentNode->_getDerivedPosition();
	_node_orient = mParentNode->_getDerivedOrientation();
	_node_trans = mParentNode->_getFullTransform();
	_node_trans_inv = _node_trans.inverse();

	_space = new SimpleSpace(space);
	_space->setInternalCollisions(false);
	_space->setAutoCleanup(false);

	_is_physical = true;
	_is_static = static_geometry;

	_joint_group = new JointGroup();

	_mesh = mMesh.getPointer();

	updateAnimation();
	_ei = new EntityInformer(this);

	Skeleton::BoneIterator rbi = mSkeletonInstance->getRootBoneIterator();

	while(rbi.hasMoreElements())
	{
		createBoneBody(rbi.getNext(),0,static_geometry);
	}
}

void Ragdoll::createBoneBody(Bone *bone,Ragdoll::PhysicalBone *parent,bool static_geometry)
{
	// We're controlling the bone now
	bone->setManuallyControlled(true);

	// Make up a name
	String body_name = mName + bone->getName();

	// Cache bone transformations
	Matrix4 bone_trans = bone->_getFullTransform();
	Vector3 bone_posn = bone->_getDerivedPosition();
	Quaternion bone_orient = bone->_getDerivedOrientation();

	// Find the settings for this bone, or use defaults
	std::map<String,Ragdoll::BoneSettings>::iterator i = _bone_settings.find(bone->getName());
	Ragdoll::BoneSettings settings = (i != _bone_settings.end())?i->second:_default_bone_settings;	
	Ragdoll::PhysicalBone *physical_bone = 0;

	// Create an oriented capsule
	if(settings._geometry_class == Geometry::Class_Capsule)
	{
		// Create the geometry
		CapsuleGeometry *geom = _ei->createOrientedCapsule(bone->getHandle(),_space);
		if(geom)
		{
			// Create a bone
			physical_bone = new Ragdoll::PhysicalBone();
			physical_bone->_body = (static_geometry)?0:(new Body(body_name));
			physical_bone->_geometry = geom;

			// Don't collapse, set capsule inertia tensor
			if(settings._collapse == Ragdoll::BoneSettings::Collapse_None)
			{
				if(physical_bone->_body) physical_bone->_body->setMass(CapsuleMass(settings._mass,((CapsuleGeometry*)(physical_bone->_geometry))->getRadius(),Vector3::UNIT_Z,((CapsuleGeometry*)(physical_bone->_geometry))->getLength()));
			}
			else
			{
				// Get the details of the capsule we created and work out where it is in relation to the bone (joint)
				Real radius = ((CapsuleGeometry*)(physical_bone->_geometry))->getRadius();
				Real length = ((CapsuleGeometry*)(physical_bone->_geometry))->getLength();
				Quaternion orient = physical_bone->_geometry->getOrientation(); 
				
				Vector3 jpos = _node_trans * bone_posn;
				Vector3 posn = physical_bone->_geometry->getPosition();
				Vector3 offs = jpos - posn;

				// Don't need the capsule geometry anymore, create a new sphere one
				delete geom;
				physical_bone->_geometry = new SphereGeometry(radius,_space);
				if(physical_bone->_body) physical_bone->_body->setMass(SphereMass(settings._mass,radius));

				// Move the geometry up away from the joint, or down to the joint
				if(settings._collapse == Ragdoll::BoneSettings::Collapse_Up)
				{
					physical_bone->_geometry->setPosition(posn - offs);
					physical_bone->_geometry->setOrientation(orient);
				}
				else
				{
					physical_bone->_geometry->setPosition(posn + offs);
					physical_bone->_geometry->setOrientation(orient);
				}
			}
		}
	}
	// Create an oriented box
	else if(settings._geometry_class == Geometry::Class_Box)
	{
		BoxGeometry *geom = _ei->createOrientedBox(bone->getHandle(),_space);
		if(geom)
		{
			physical_bone = new Ragdoll::PhysicalBone();
			physical_bone->_body = (static_geometry)?0:(new Body(body_name));
			physical_bone->_geometry = geom;

			if(physical_bone->_body) physical_bone->_body->setMass(BoxMass(settings._mass,((BoxGeometry*)(physical_bone->_geometry))->getSize()));
		}
	}
	// Don't create any geometry
	else if(settings._geometry_class == Geometry::Class_NoGeometry)
	{
		physical_bone = new Ragdoll::PhysicalBone();
		physical_bone->_body = (static_geometry)?0:(new Body(body_name));

		if(physical_bone->_body)
		{
			physical_bone->_body->setMass(SphereMass(settings._mass,settings._radius));
			physical_bone->_body->setPosition(_node_trans * bone_posn);
		}
	}
	
	if(physical_bone)
	{
		// Sync the body and geometry
		if((physical_bone->_body)&&(physical_bone->_geometry))
		{
			physical_bone->_body->setPosition(physical_bone->_geometry->getPosition());
			physical_bone->_body->setOrientation(physical_bone->_geometry->getOrientation());
		}

		if(physical_bone->_geometry)
		{
			physical_bone->_geometry->setBody(physical_bone->_body);
			physical_bone->_geometry->setPrefabObject(this);
		}

		if(physical_bone->_body)
		{
			physical_bone->_original_orientation = bone_orient.UnitInverse() * (_node_orient.UnitInverse() * physical_bone->_body->getOrientation());
			physical_bone->_original_position = physical_bone->_body->getPointBodyPosition(_node_trans * bone_posn);

			physical_bone->_body->setDamping(settings._linear_damping,settings._angular_damping);
		}

		physical_bone->_parent_bone = parent;
		physical_bone->_bone = bone;

		if((physical_bone->_parent_bone)&&(physical_bone->_parent_bone->_body)&&(physical_bone->_body))
		{
			if(settings._joint_type == Joint::Type_BallJoint)
			{
				physical_bone->_joint = new BallJoint(_joint_group);
				physical_bone->_joint->attach(physical_bone->_parent_bone->_body,physical_bone->_body);
				physical_bone->_joint->setAnchor(_node_trans * bone_posn);

				physical_bone->_motor = new AngularMotorJoint(_joint_group);
				physical_bone->_motor->attach(physical_bone->_parent_bone->_body,physical_bone->_body);
				physical_bone->_motor->setMode(AngularMotorJoint::Mode_UserAngularMotor);
				physical_bone->_motor->setAnchor(_node_trans * bone_posn);
				physical_bone->_motor->setAxisCount(2);
				
				physical_bone->_motor->setAxis(1,AngularMotorJoint::RelativeOrientation_FirstBody,(_node_orient * physical_bone->_parent_bone->_bone->_getDerivedOrientation()) * settings._primary_axis);
				physical_bone->_motor->setAngle(1,0);
				physical_bone->_motor->setParameter(Joint::Parameter_LowStop,settings._primary_lostop,1);
				physical_bone->_motor->setParameter(Joint::Parameter_HighStop,settings._primary_histop,1);

				physical_bone->_motor->setAxis(2,AngularMotorJoint::RelativeOrientation_FirstBody,(_node_orient * physical_bone->_parent_bone->_bone->_getDerivedOrientation()) * settings._secondary_axis);
				physical_bone->_motor->setAngle(2,0);
				physical_bone->_motor->setParameter(Joint::Parameter_LowStop,settings._secondary_lostop,2);
				physical_bone->_motor->setParameter(Joint::Parameter_HighStop,settings._secondary_histop,2);
			}
			else if(settings._joint_type == Joint::Type_HingeJoint)
			{
				physical_bone->_joint = new HingeJoint(_joint_group);
				physical_bone->_joint->attach(physical_bone->_parent_bone->_body,physical_bone->_body);
				physical_bone->_joint->setAnchor(_node_trans * bone_posn);
				physical_bone->_joint->setAxis((_node_orient * physical_bone->_parent_bone->_bone->_getDerivedOrientation()) * settings._primary_axis);

				physical_bone->_joint->setParameter(Joint::Parameter_LowStop,settings._primary_lostop);
				physical_bone->_joint->setParameter(Joint::Parameter_HighStop,settings._primary_histop);
			}
			else if(settings._joint_type == Joint::Type_UniversalJoint)
			{
				physical_bone->_joint = new UniversalJoint(_joint_group);
				physical_bone->_joint->attach(physical_bone->_parent_bone->_body,physical_bone->_body);
				physical_bone->_joint->setAnchor(_node_trans * bone_posn);
				physical_bone->_joint->setAxis((_node_orient * physical_bone->_parent_bone->_bone->_getDerivedOrientation()) * settings._primary_axis);
				physical_bone->_joint->setAdditionalAxis((_node_orient * physical_bone->_parent_bone->_bone->_getDerivedOrientation()) * settings._secondary_axis);

				physical_bone->_joint->setParameter(Joint::Parameter_LowStop,settings._primary_lostop);
				physical_bone->_joint->setParameter(Joint::Parameter_HighStop,settings._primary_histop);

				physical_bone->_joint->setParameter(Joint::Parameter_LowStop,settings._secondary_lostop,2);
				physical_bone->_joint->setParameter(Joint::Parameter_HighStop,settings._secondary_histop,2);
			}
			else if(settings._joint_type == Joint::Type_FixedJoint)
			{
				physical_bone->_joint = new FixedJoint(_joint_group);
				physical_bone->_joint->attach(physical_bone->_parent_bone->_body,physical_bone->_body);
				physical_bone->_joint->setAnchor(_node_trans * bone_posn);
			}

			physical_bone->_parent_bone->_child_bones.push_back(physical_bone);
		}
		else _root_bones.push_back(physical_bone);
	}

	Node::ChildNodeIterator cni = bone->getChildIterator();
	while(cni.hasMoreElements())
	{
		createBoneBody((Bone*)cni.getNext(),(physical_bone)?physical_bone:parent,static_geometry);
	}
}

void Ragdoll::turnToStone(Ragdoll::PhysicalBone* bone)
{
	bone->_geometry->setBody(0);

	delete bone->_motor;
	delete bone->_joint;
	delete bone->_body;

	bone->_motor = 0;
	bone->_joint = 0;
	bone->_body = 0;

	for(std::vector<Ragdoll::PhysicalBone*>::iterator i = bone->_child_bones.begin();i != bone->_child_bones.end();++i)
	{
		turnToStone(*i);
	}
}

void Ragdoll::turnToStone()
{
	if(!_is_static)
	{
		for(std::vector<Ragdoll::PhysicalBone*>::iterator i = _root_bones.begin();i != _root_bones.end();++i)
		{
			turnToStone(*i);
		}

		delete _joint_group;
		_joint_group = 0;

		_is_static = true;
	}
}

void Ragdoll::releasePhysicalControl(Ragdoll::PhysicalBone* bone)
{
	bone->_bone->setManuallyControlled(false);

	delete bone->_geometry;
	bone->_geometry = 0;

	for(std::vector<Ragdoll::PhysicalBone*>::iterator i = bone->_child_bones.begin();i != bone->_child_bones.end();++i)
	{
		releasePhysicalControl(*i);
	}
}

void Ragdoll::releasePhysicalControl()
{
	turnToStone();

	if(_is_physical)
	{
		for(std::vector<Ragdoll::PhysicalBone*>::iterator i = _root_bones.begin();i != _root_bones.end();++i)
		{
			releasePhysicalControl(*i);
			delete (*i);
		}
		_root_bones.clear();

		delete _space;
		_space = 0;

		_is_physical = false;
	}
}

void Ragdoll::updatePhysicalBone(Ragdoll::PhysicalBone *physical_bone,const Matrix4 &this_trans,const Matrix4 &base_trans)
{
	Quaternion body_orient = physical_bone->_body->getOrientation() * physical_bone->_original_orientation.UnitInverse();
	Quaternion bone_orient = Quaternion::IDENTITY;

	Vector3 body_posn = physical_bone->_body->getPointWorldPosition(physical_bone->_original_position);
	Vector3 bone_posn = Vector3::ZERO;

	Matrix3 bone_rot;
	body_orient.ToRotationMatrix(bone_rot);

	Matrix4 bone_trans = Matrix4::IDENTITY;
	bone_trans = bone_rot;
	bone_trans.setTrans(body_posn);

	bone_trans = this_trans.inverse() * bone_trans;

	bone_posn = Vector3(bone_trans[0][3],bone_trans[1][3],bone_trans[2][3]);
	bone_trans.extract3x3Matrix(bone_rot);
	bone_orient.FromRotationMatrix(bone_rot);

	physical_bone->_bone->setOrientation(bone_orient);
	physical_bone->_bone->setPosition(bone_posn);

	for(std::vector<Ragdoll::PhysicalBone*>::iterator i = physical_bone->_child_bones.begin();i != physical_bone->_child_bones.end();++i)
	{
		updatePhysicalBone(*i,base_trans * (*i)->_bone->getParent()->_getFullTransform(),base_trans);
	}
}

void Ragdoll::update()
{
	if((_is_physical) && (!_is_static))
	{		
		for(std::vector<Ragdoll::PhysicalBone*>::iterator i = _root_bones.begin();i != _root_bones.end();++i)
		{
			updatePhysicalBone(*i,_node_trans,_node_trans);
		}
		mParentNode->needUpdate();
	}
}

const AxisAlignedBox& Ragdoll::getBoundingBox(void) const
{
	if(_space)
	{
		// Get from space and convert to local 
		*mFullBoundingBox = _space->getAxisAlignedBox();
		mFullBoundingBox->transform(_node_trans_inv);
	}
	else
	{
		// Get from Mesh
		*mFullBoundingBox = mMesh->getBounds();
		mFullBoundingBox->merge(getChildObjectsBoundingBox());
	}
	return *mFullBoundingBox;
}

bool Ragdoll::collision(Contact* contact)
{
	Body *body = contact->getFirstGeometry()->getBody();
	if(!body) body = contact->getSecondGeometry()->getBody();
	_hit_list.push_back(std::pair<Body*,Vector3>(body,contact->getPosition()));
	return false;
}

void Ragdoll::pick(Ragdoll::PhysicalBone *bone,RayGeometry *ray)
{
	if(bone->_geometry) ray->collide(bone->_geometry,this);
	
	for(std::vector<Ragdoll::PhysicalBone*>::iterator i = bone->_child_bones.begin();i != bone->_child_bones.end();++i)
	{
		pick(*i,ray);
	}
}

bool Ragdoll::pick(RayGeometry *ray,Body* &body,Vector3 &position)
{
	_hit_list.clear();
	for(std::vector<Ragdoll::PhysicalBone*>::iterator i = _root_bones.begin();i != _root_bones.end();++i)
	{
		pick(*i,ray);
	}

	bool rc = (_hit_list.size())?true:false;

	if(rc)
	{
	Real dist = ray->getLength();
	for(std::vector<std::pair<Body*,Vector3> >::iterator i = _hit_list.begin();i != _hit_list.end();++i)
	{
		Real this_dist = (i->second - ray->getPosition()).length();
		if(this_dist < dist)
		{
			body = i->first;
			position = i->second;
		}
	}
	}

	return rc;
}

void Ragdoll::parseSettings(Ragdoll::BoneSettings &bone_settings,const void *tag)
{
	const TiXmlElement *element = (const TiXmlElement *)tag;

	for(const TiXmlNode *node = element->FirstChild(); node; node = node->NextSibling() )
	{
		if((node->Type() ==  TiXmlNode::ELEMENT) && (!stricmp(node->Value(),"settings")))
		{
			const TiXmlElement *settings = (const TiXmlElement*)node;
			double tmp;
			
			if(settings->Attribute("geometry"))
			{
				if(!strcmp(settings->Attribute("geometry"),"capsule")) bone_settings._geometry_class = Geometry::Class_Capsule;
				else if(!strcmp(settings->Attribute("geometry"),"box")) bone_settings._geometry_class = Geometry::Class_Box;
				else if(!strcmp(settings->Attribute("geometry"),"none")) bone_settings._geometry_class = Geometry::Class_NoGeometry;
			}

			if(settings->Attribute("joint"))
			{
				if(!strcmp(settings->Attribute("joint"),"fixed")) bone_settings._joint_type = Joint::Type_FixedJoint;
				else if(!strcmp(settings->Attribute("joint"),"hinge")) bone_settings._joint_type = Joint::Type_HingeJoint;
				else if(!strcmp(settings->Attribute("joint"),"ball")) bone_settings._joint_type = Joint::Type_BallJoint;
				else if(!strcmp(settings->Attribute("joint"),"universal")) bone_settings._joint_type = Joint::Type_UniversalJoint;
			}

			if(settings->Attribute("joint"))
			{
				if(!strcmp(settings->Attribute("joint"),"fixed")) bone_settings._joint_type = Joint::Type_FixedJoint;
				else if(!strcmp(settings->Attribute("joint"),"hinge")) bone_settings._joint_type = Joint::Type_HingeJoint;
				else if(!strcmp(settings->Attribute("joint"),"ball")) bone_settings._joint_type = Joint::Type_BallJoint;
				else if(!strcmp(settings->Attribute("joint"),"universal")) bone_settings._joint_type = Joint::Type_UniversalJoint;
			}
					
			if(settings->Attribute("collapse"))
			{
				if(!strcmp(settings->Attribute("collapse"),"none")) bone_settings._collapse = BoneSettings::Collapse_None;
				else if(!strcmp(settings->Attribute("collapse"),"up")) bone_settings._collapse = BoneSettings::Collapse_Up;
				else if(!strcmp(settings->Attribute("collapse"),"down")) bone_settings._collapse = BoneSettings::Collapse_Down;
			}

			if(settings->Attribute("mass",&tmp)) bone_settings._mass = (Real)tmp;
			if(settings->Attribute("radius",&tmp)) bone_settings._radius = (Real)tmp;

			for(const TiXmlNode *sub_node = node->FirstChild(); sub_node; sub_node = sub_node->NextSibling() )
			{
				if(sub_node->Type() ==  TiXmlNode::ELEMENT)
				{
					const TiXmlElement *sub_settings = (const TiXmlElement*)sub_node;

					if(!stricmp(sub_node->Value(),"damping"))
					{
						if(sub_settings->Attribute("angular",&tmp)) bone_settings._angular_damping = (Real)tmp;
						if(sub_settings->Attribute("linear",&tmp)) bone_settings._linear_damping = (Real)tmp;
					}
					else if(!stricmp(sub_node->Value(),"axis"))
					{
						int n;
						if(sub_settings->Attribute("number",&n))
						{
							if(n == 1)
							{
								if(sub_settings->Attribute("x",&tmp)) bone_settings._primary_axis.x = (Real)tmp;
								if(sub_settings->Attribute("y",&tmp)) bone_settings._primary_axis.y = (Real)tmp;
								if(sub_settings->Attribute("z",&tmp)) bone_settings._primary_axis.z = (Real)tmp;

								bone_settings._primary_axis.normalise();
							}
							else if(n == 2)
							{
								if(sub_settings->Attribute("x",&tmp)) bone_settings._secondary_axis.x = (Real)tmp;
								if(sub_settings->Attribute("y",&tmp)) bone_settings._secondary_axis.y = (Real)tmp;
								if(sub_settings->Attribute("z",&tmp)) bone_settings._secondary_axis.z = (Real)tmp;

								bone_settings._secondary_axis.normalise();
							}

							for(const TiXmlNode *sub_sub_node = sub_node->FirstChild(); sub_sub_node; sub_sub_node = sub_sub_node->NextSibling() )
							{
								if((sub_sub_node->Type() ==  TiXmlNode::ELEMENT) && (!stricmp(sub_sub_node->Value(),"stop")))
								{
									const TiXmlElement *sub_sub_settings = (const TiXmlElement*)sub_sub_node;

									if(n == 1)
									{
										if(sub_sub_settings->Attribute("low",&tmp)) bone_settings._primary_lostop = (Real)tmp;
										if(sub_sub_settings->Attribute("high",&tmp)) bone_settings._primary_histop = (Real)tmp;
									}
									else if(n == 2)
									{
										if(sub_sub_settings->Attribute("low",&tmp)) bone_settings._secondary_lostop = (Real)tmp;
										if(sub_sub_settings->Attribute("high",&tmp)) bone_settings._secondary_histop = (Real)tmp;
									}
								}	
							}
						}
					}
				}
			}
		}
	}
}

void Ragdoll::load(const String &filename,const String &ragdoll_name)
{
	DataStreamPtr file = ResourceGroupManager::getSingleton().openResource(filename);
	TiXmlDocument *doc = new TiXmlDocument(filename.c_str());
	doc->Parse(file->getAsString().c_str());
	if(doc->Error())
	{
		throw new Exception(doc->ErrorId(),doc->ErrorDesc(),__FILE__,((char*)(file->getName().c_str())),doc->ErrorRow());
	}

	const TiXmlElement *root = doc->RootElement();
	for(const TiXmlNode *child = root->FirstChild(); child; child = child->NextSibling() )
	{
		if((child->Type() == TiXmlNode::ELEMENT) && (!strcmp(child->Value(),"ragdoll")))
		{
			const TiXmlElement *ragdoll = (const TiXmlElement*)child;
			if((ragdoll_name == StringUtil::BLANK) || ((ragdoll->Attribute("name")) && (!strcmp(ragdoll->Attribute("name"),ragdoll_name.c_str()))))
			{
				BoneSettings settings;

				for(const TiXmlNode *tag = child->FirstChild(); tag; tag = tag->NextSibling() )
				{
					if(tag->Type() == TiXmlNode::ELEMENT)
					{
						if(!strcmp(tag->Value(),"defaults"))
						{
							parseSettings(settings,tag);
							setDefaultBoneSettings(settings);
						}
						else if((!strcmp(tag->Value(),"bone")) && (((const TiXmlElement*)tag)->Attribute("name")))
						{
							parseSettings(settings,tag);
							setBoneSettings(((const TiXmlElement*)tag)->Attribute("name"),settings); 
						}
					}
				}
				break;
			}
		}
	}

	delete doc;
}

Ragdoll::~Ragdoll()
{
	for(std::vector<Ragdoll::PhysicalBone*>::iterator i = _root_bones.begin();i != _root_bones.end();++i) delete (*i);
	delete _space;
	delete _ei;
	delete _joint_group;
}
