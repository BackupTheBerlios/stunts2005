#include "OgreOdeEntityInformer.h"
#include "OgreOdeMaintainedList.h"
#include "OgreOdeBody.h"
#include "OgreOdeGeometry.h"
#include "OgreOdeMass.h"
#include "OgreOdeEigenSolver.h"

using namespace OgreOde;

void EntityInformer::addVertexData(const VertexData *vertex_data,const VertexData *blended_data)
{
	if(!vertex_data) return;

	const VertexData *data = (blended_data)?blended_data:vertex_data;

	size_t prev_size = _vertex_count;
	_vertex_count += data->vertexCount;

	Vector3* tmp_vert = new Vector3[_vertex_count];
	if(_vertices)
	{
		memcpy(tmp_vert,_vertices,sizeof(Vector3) * prev_size);
		delete[] _vertices;
	}
	_vertices = tmp_vert;

	// Get the positional buffer element
	const Ogre::VertexElement* posElem = data->vertexDeclaration->findElementBySemantic(Ogre::VES_POSITION);			
	Ogre::HardwareVertexBufferSharedPtr vbuf = data->vertexBufferBinding->getBuffer(posElem->getSource());
	unsigned char* vertex = static_cast<unsigned char*>(vbuf->lock(Ogre::HardwareBuffer::HBL_READ_ONLY));
	Ogre::Real* pReal;

	for(size_t j = 0; j < data->vertexCount; ++j, vertex += vbuf->getVertexSize())
	{
		posElem->baseVertexPointerToElement(vertex, &pReal);

		_vertices[prev_size + j].x = (*pReal++);
		_vertices[prev_size + j].y = (*pReal++);
		_vertices[prev_size + j].z = (*pReal++);

		_vertices[prev_size + j] = _transform * _vertices[prev_size + j];
	}
	vbuf->unlock();

	// Get the bone index element
	if(_entity->hasSkeleton())
	{
		const Ogre::VertexElement* bneElem = vertex_data->vertexDeclaration->findElementBySemantic(Ogre::VES_BLEND_INDICES);
		if(bneElem)
		{
			vbuf = vertex_data->vertexBufferBinding->getBuffer(bneElem->getSource());
			vertex = static_cast<unsigned char*>(vbuf->lock(Ogre::HardwareBuffer::HBL_READ_ONLY));

			unsigned short* pBone;

			for(size_t j = 0; j < vertex_data->vertexCount; ++j, vertex += vbuf->getVertexSize())
			{
				bneElem->baseVertexPointerToElement(vertex, &pBone);

				if(!_bone_mapping)
				{
					_bone_mapping = new std::map<unsigned short,std::vector<Vector3>* >;		
				}						

				std::map<unsigned short,std::vector<Vector3>* >::iterator i = _bone_mapping->find(*pBone);
				std::vector<Vector3>* l = 0;
				if(i == _bone_mapping->end())
				{
					l = new std::vector<Vector3>;
					_bone_mapping->insert(std::pair<unsigned short,std::vector<Vector3>* >(*pBone,l));
				}						
				else l = i->second;

				l->push_back(_vertices[prev_size + j]);
			}
			vbuf->unlock();
		}
	}
}

void EntityInformer::addIndexData(IndexData *data,size_t offset)
{
	size_t prev_size = _index_count;
	_index_count += data->indexCount;

	int* tmp_ind = new int[_index_count];
	if(_indices)
	{
		memcpy(tmp_ind,_indices,sizeof(int) * prev_size);
		delete[] _indices;
	}
	_indices = tmp_ind;

	size_t numTris = data->indexCount / 3;
	size_t index_offset = prev_size;

	unsigned short* pShort;
	unsigned int* pInt;
	
	HardwareIndexBufferSharedPtr ibuf = data->indexBuffer;
	
	bool use32bitindexes = (ibuf->getType() == HardwareIndexBuffer::IT_32BIT);
	if (use32bitindexes) pInt = static_cast<unsigned int*>(ibuf->lock(HardwareBuffer::HBL_READ_ONLY));
	else pShort = static_cast<unsigned short*>(ibuf->lock(HardwareBuffer::HBL_READ_ONLY));

	for(size_t k = 0; k < numTris; ++k)
	{
		unsigned int vindex = use32bitindexes? *pInt++ : *pShort++;
		_indices[index_offset + 0] = vindex + offset;
		vindex = use32bitindexes? *pInt++ : *pShort++;
		_indices[index_offset + 1] = vindex + offset;
		vindex = use32bitindexes? *pInt++ : *pShort++;
		_indices[index_offset + 2] = vindex + offset;

		index_offset += 3;
	}
	ibuf->unlock();
}

EntityInformer::EntityInformer(Entity *entity,const Matrix4 &transform)
{
	_entity = entity;
	_node = (SceneNode*)(_entity->getParentNode());
	_transform = transform;

	_vertices = 0;
	_indices = 0;
	_vertex_count = 0;
	_index_count = 0;
	
	_size = Vector3(-1,-1,-1);
	_radius = -1;

	_bone_mapping = 0;

	addVertexData(_entity->getMesh()->sharedVertexData,(_entity->hasSkeleton())?_entity->_getSharedBlendedVertexData():0);

	for(unsigned int i = 0;i < _entity->getNumSubEntities();++i)
	{
		SubMesh *sub_mesh = _entity->getSubEntity(i)->getSubMesh();

		if(!sub_mesh->useSharedVertices)
		{
			addIndexData(sub_mesh->indexData,_vertex_count);
			addVertexData(sub_mesh->vertexData,(_entity->hasSkeleton())?_entity->getSubEntity(i)->_getBlendedVertexData():0);
		}
		else addIndexData(sub_mesh->indexData);
	}
}

Real EntityInformer::getRadius()
{
	if(_radius == (-1))
	{
		getSize();
		_radius = (std::max(_size.x,std::max(_size.y,_size.z)) * 0.5);
	}
	return _radius;
}

Vector3 EntityInformer::getSize()
{
	if(_size == Vector3(-1,-1,-1))
	{
		Vector3 vmin(FLT_MAX,FLT_MAX,FLT_MAX);
		Vector3 vmax(FLT_MIN,FLT_MIN,FLT_MIN);

		int i = getVertexCount();
		const Vector3* v = getVertices();

		for(int j = 0;j < i;j++)
		{
			vmin.x = std::min(vmin.x,v[j].x);
			vmin.y = std::min(vmin.y,v[j].y);
			vmin.z = std::min(vmin.z,v[j].z);

			vmax.x = std::max(vmax.x,v[j].x);
			vmax.y = std::max(vmax.y,v[j].y);
			vmax.z = std::max(vmax.z,v[j].z);
		}

		_size.x = vmax.x - vmin.x;
		_size.y = vmax.y - vmin.y;
		_size.z = vmax.z - vmin.z;
	}

	return _size;
}

const Vector3* EntityInformer::getVertices()
{
	return _vertices;
}

unsigned int EntityInformer::getVertexCount()
{
	return (unsigned int)_vertex_count;
}

const int* EntityInformer::getIndices()
{
	return _indices;
}

unsigned int EntityInformer::getIndexCount()
{
	return (unsigned int)_index_count;
}

Body* EntityInformer::createSingleDynamicSphere(Real mass,Space* space)
{
	Real rad = getRadius();

	assert((rad > 0.0) && ("Sphere radius must be greater than zero"));

	Body* body = new Body("OgreOde::Body_" + _entity->getName());
	body->setMass(SphereMass(mass,rad));

	SphereGeometry* geom = new SphereGeometry(rad,space);
	geom->setBody(body);

	body->setPosition(_node->getPosition());
	body->setOrientation(_node->getOrientation());

	_node->attachObject(body);

	return body;
}

Body* EntityInformer::createSingleDynamicBox(Real mass,Space* space)
{
	Vector3 sz = getSize();

	assert((sz.x > 0.0) && (sz.y > 0.0) && (sz.y > 0.0) && ("Size of box must be greater than zero on all axes"));

	Body* body = new Body("OgreOde::Body_" + _node->getName());
	body->setMass(BoxMass(mass,sz));

	BoxGeometry* geom = new BoxGeometry(sz,space);
	geom->setBody(body);

	body->setPosition(_node->getPosition());
	body->setOrientation(_node->getOrientation());

	_node->attachObject(body);

	return body;
}

TriangleMeshGeometry* EntityInformer::createStaticTriangleMesh(Space* space)
{
	assert(_vertex_count && (_index_count >= 6) && "Mesh must have some vertices and at least 6 indices (2 triangles)");

	return new TriangleMeshGeometry(_vertices,(int)_vertex_count,_indices,(int)_index_count,space);
}

BoxGeometry* EntityInformer::createSingleStaticBox(Space* space)
{
	BoxGeometry* geom = new BoxGeometry(getSize(),space);

	geom->setPosition(_node->getPosition());
	geom->setOrientation(_node->getOrientation());

	return geom;
}

bool EntityInformer::getBoneVertices(unsigned short bone,size_t &vertex_count,Vector3* &vertices)
{
	std::map<unsigned short,std::vector<Vector3>* >::iterator i = _bone_mapping->find(bone);
	if(i == _bone_mapping->end()) return false;

	vertex_count = i->second->size() + 1;
	if(!vertex_count) return false;

	vertices = new Vector3[vertex_count];
	vertices[0] = _entity->_getParentNodeFullTransform() * _entity->getSkeleton()->getBone(bone)->_getDerivedPosition();

	int o = 1;
	for(std::vector<Vector3>::iterator j = i->second->begin();j != i->second->end();++j,++o) vertices[o] = (*j);

	return true;
}

BoxGeometry* EntityInformer::createAlignedBox(unsigned short bone,Space* space)
{
	size_t vertex_count;
	Vector3* vertices;
	if(!getBoneVertices(bone,vertex_count,vertices)) return 0;

	Vector3 min_vec(FLT_MAX,FLT_MAX,FLT_MAX);
	Vector3 max_vec(-FLT_MAX,-FLT_MAX,-FLT_MAX);

	for(unsigned int j = 0;j < vertex_count;j++)
	{
		min_vec.x = std::min(min_vec.x,vertices[j].x);
		min_vec.y = std::min(min_vec.y,vertices[j].y);
		min_vec.z = std::min(min_vec.z,vertices[j].z);

		max_vec.x = std::max(max_vec.x,vertices[j].x);
		max_vec.y = std::max(max_vec.y,vertices[j].y);
		max_vec.z = std::max(max_vec.z,vertices[j].z);
	}

	Vector3 pos;

	pos.x = min_vec.x + ((max_vec.x - min_vec.x) * 0.5);
	pos.y = min_vec.y + ((max_vec.y - min_vec.y) * 0.5);
	pos.z = min_vec.z + ((max_vec.z - min_vec.z) * 0.5);

	BoxGeometry* box = new BoxGeometry(max_vec - min_vec,space);
	box->setPosition(pos);

	delete[] vertices;
	return box;
}

BoxGeometry* EntityInformer::createOrientedBox(unsigned short bone,Space* space)
{
	size_t vertex_count;
	Vector3* vertices;
	if(!getBoneVertices(bone,vertex_count,vertices)) return 0;

	Vector3 box_kCenter;
    Vector3 box_akAxis[3];
    Real box_afExtent[3];

	EigenSolver::GaussPointsFit((int)vertex_count,vertices,box_kCenter,box_akAxis,box_afExtent);

    // Let C be the box center and let U0, U1, and U2 be the box axes.  Each
    // input point is of the form X = C + y0*U0 + y1*U1 + y2*U2.  The
    // following code computes min(y0), max(y0), min(y1), max(y1), min(y2),
    // and max(y2).  The box center is then adjusted to be
    //   C' = C + 0.5*(min(y0)+max(y0))*U0 + 0.5*(min(y1)+max(y1))*U1 +
    //        0.5*(min(y2)+max(y2))*U2

    Vector3 kDiff = vertices[0] - box_kCenter;
    Real fY0Min = kDiff.dotProduct(box_akAxis[0]), fY0Max = fY0Min;
    Real fY1Min = kDiff.dotProduct(box_akAxis[1]), fY1Max = fY1Min;
    Real fY2Min = kDiff.dotProduct(box_akAxis[2]), fY2Max = fY2Min;

    for (size_t i = 1; i < vertex_count; i++)
    {
        kDiff = vertices[i] - box_kCenter;

        Real fY0 = kDiff.dotProduct(box_akAxis[0]);
        if ( fY0 < fY0Min )
            fY0Min = fY0;
        else if ( fY0 > fY0Max )
            fY0Max = fY0;

        Real fY1 = kDiff.dotProduct(box_akAxis[1]);
        if ( fY1 < fY1Min )
            fY1Min = fY1;
        else if ( fY1 > fY1Max )
            fY1Max = fY1;

        Real fY2 = kDiff.dotProduct(box_akAxis[2]);
        if ( fY2 < fY2Min )
            fY2Min = fY2;
        else if ( fY2 > fY2Max )
            fY2Max = fY2;
    }

    box_kCenter += (((Real)0.5)*(fY0Min+fY0Max))*box_akAxis[0] +
        (((Real)0.5)*(fY1Min+fY1Max))*box_akAxis[1] +
        (((Real)0.5)*(fY2Min+fY2Max))*box_akAxis[2];

    box_afExtent[0] = ((Real)0.5)*(fY0Max - fY0Min);
    box_afExtent[1] = ((Real)0.5)*(fY1Max - fY1Min);
    box_afExtent[2] = ((Real)0.5)*(fY2Max - fY2Min);
	
	BoxGeometry *geom = new BoxGeometry(Vector3(box_afExtent[0] * 2.0,box_afExtent[1] * 2.0,box_afExtent[2] * 2.0),space);
	geom->setOrientation(Quaternion(box_akAxis[0],box_akAxis[1],box_akAxis[2]));
	geom->setPosition(box_kCenter);
	return geom;
}

CapsuleGeometry* EntityInformer::createOrientedCapsule(unsigned short bone,Space* space)
{
	size_t vertex_count;
	Vector3* vertices;
	if(!getBoneVertices(bone,vertex_count,vertices)) return 0;

	Vector3 cap_orig;
	Vector3 cap_dir;
	Real cap_rad;

	Vector3 line_orig;
	Vector3 line_dir;

	EigenSolver::orthogonalLineFit((int)vertex_count,vertices,line_orig,line_dir);

    Real fMaxRadiusSqr = (Real)0.0;
    unsigned int c;
    for (c = 0; c < vertex_count; c++)
    {
		Real fRadiusSqr = EigenSolver::SqrDistance(vertices[c],line_orig,line_dir);
        if ( fRadiusSqr > fMaxRadiusSqr ) fMaxRadiusSqr = fRadiusSqr;
    }

    Vector3 kU, kV, kW = line_dir;
	EigenSolver::GenerateOrthonormalBasis(kU,kV,kW,true);

    Real fMin = FLT_MAX, fMax = -fMin;
    for (c = 0; c < vertex_count; c++)
    {
        Vector3 kDiff = vertices[c] - line_orig;
        Real fU = kU.dotProduct(kDiff);
        Real fV = kV.dotProduct(kDiff);
        Real fW = kW.dotProduct(kDiff);
        Real fDiscr = fMaxRadiusSqr - (fU*fU + fV*fV);
        Real fRadical = sqrtf(fabs(fDiscr));

        Real fTest = fW + fRadical;
        if ( fTest < fMin ) fMin = fTest;

        fTest = fW - fRadical;
        if ( fTest > fMax ) fMax = fTest;
    }

    if ( fMin < fMax )
    {
        cap_orig = line_orig + fMin*line_dir;
        cap_dir = (fMax-fMin)*line_dir;
    }
    else
    {
        // enclosing capsule is really a sphere
        cap_orig = line_orig + (((Real)0.5)*(fMin+fMax))*line_dir;
        cap_dir = Vector3::ZERO;
    }

    cap_rad = sqrtf(fMaxRadiusSqr);

	Vector3 orig_axis = Vector3::UNIT_Z;
	Vector3 reqd_axis = cap_dir.normalisedCopy();
	Vector3 rot_axis = orig_axis.crossProduct(reqd_axis);
	Real cos_ang = orig_axis.dotProduct(reqd_axis);
	Real ang = acos(cos_ang);
	if(cos_ang < 0.0) ang -= M_PI;
	
	Quaternion orient = Quaternion(Radian(ang),rot_axis);

	CapsuleGeometry* geom = new CapsuleGeometry(cap_rad,cap_dir.length(),space);
	geom->setOrientation(orient);
	geom->setPosition(cap_orig + (reqd_axis * (cap_dir.length() * 0.5)));
	
	return geom;
}

EntityInformer::~EntityInformer()
{
	delete[] _vertices;
	delete[] _indices;

	if(_bone_mapping)
	{
		for(std::map<unsigned short,std::vector<Vector3>* >::iterator i = _bone_mapping->begin();i != _bone_mapping->end();++i)
		{
			delete i->second;
		}
		delete _bone_mapping;
	}
}
