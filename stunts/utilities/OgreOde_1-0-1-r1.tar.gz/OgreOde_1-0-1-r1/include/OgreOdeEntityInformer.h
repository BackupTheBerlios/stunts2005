#ifndef _OGREODEENTITYINFORMER_H_
#define _OGREODEENTITYINFORMER_H_

#include "OgreOdePreReqs.h"

namespace OgreOde 
{
    class _OgreOdeExport EntityInformer
    {
	public:
		EntityInformer(Entity *entity,const Matrix4 &transform = Matrix4::IDENTITY);
		~EntityInformer();

		Real getRadius();
		Vector3 getSize();

		Body* createSingleDynamicSphere(Real mass,Space* space = 0);
		Body* createSingleDynamicBox(Real mass,Space* space = 0);

		TriangleMeshGeometry* createStaticTriangleMesh(Space* space = 0);
		BoxGeometry* createSingleStaticBox(Space* space = 0);

		CapsuleGeometry* createOrientedCapsule(unsigned short bone,Space* space = 0);
		BoxGeometry* createOrientedBox(unsigned short bone,Space* space = 0);
		BoxGeometry* createAlignedBox(unsigned short bone,Space* space = 0);

		const Vector3* getVertices();
		unsigned int getVertexCount();
		const int* getIndices();
		unsigned int getIndexCount();

	protected:
		void addVertexData(const VertexData *vertex_data,const VertexData *blended_data = 0);
		void addIndexData(IndexData *data,size_t offset = 0);
		bool getBoneVertices(unsigned short bone,size_t &vertex_count,Vector3* &vertices);

		Entity*		_entity;
		SceneNode*	_node;
		Matrix4		_transform;

		Real		_radius;
		Vector3		_size;

		Vector3*	_vertices;
		int*		_indices;
		size_t		_vertex_count;
		size_t		_index_count;

		std::map<unsigned short,std::vector<Vector3>* >* _bone_mapping;
	};
}

#endif


