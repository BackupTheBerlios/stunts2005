#include <fstream>

#include <boost/archive/xml_oarchive.hpp>
#include <boost/archive/xml_iarchive.hpp>

#include <boost/serialization/list.hpp>

#include <boost/serialization/export.hpp>

#include <string>
using std::string;

#include <iostream>
using std::cerr;
using std::endl;

#include <list>
using std::list;

/** A pseudo vector.
 */
class Vector {
public:
  Vector()
  {}
  
  Vector(float x, float y, float z)
    : __x(x)
    , __y(y)
    , __z(z)
  {}
  
private:
  friend class boost::serialization::access;
  
  /** Serialization method.  This template method serializes the
   * object to an archive. This is done by serializing all members.
   * Members are serialized as name-value pairs using @c
   * make_nvp. This is required for XML support, but not required in
   * general.
   */
  template<class Archive>
  void serialize(Archive & ar, const unsigned int version) {
    ar & boost::serialization::make_nvp("x", __x);
    ar & boost::serialization::make_nvp("y", __y);
    ar & boost::serialization::make_nvp("z", __z);
  }
  
private:
  float __x, __y, __z;
};

/* set the implementation level for serialization of a Vector object. The default for classes and structs is class_information,
   which is most powerful and has most overhead. Data structures which are serialized very frequently, such as 3d vectors, and need less features
   should define a lower implementation level, such as object_serialization. See the BOOST documentation for details. */
BOOST_CLASS_IMPLEMENTATION(Vector, boost::serialization::object_serializable)

/** A pseudo game object.  This class is an example for a serializable
 * base class. It has several derived classes that are also
 * serializable.
 */
class GameObject {
public:
  GameObject() {
    cerr << "created a GameObject " << this << endl;
  }
  
  virtual ~GameObject() {}
  
  void setName(const string& name) {
    __name = name;
  }
  
  void setPosition(const Vector& position) {
    __position = position;
  }
  
  const string& getName() const {
    return __name;
  }
  
  const Vector& getPosition() const {
    return __position;
  }
  
private:
  friend class boost::serialization::access;
  
  template<class Archive>
  void serialize(Archive & ar, const unsigned int version) {
    ar & boost::serialization::make_nvp("name", __name);
    ar & boost::serialization::make_nvp("position", __position);
  }
  
private:
  string __name;
  Vector __position;
};

/* export the class GameObject. This must go into the header file of the class. Normally it is not necessary, however for polymorphic classes
   which are typically serialized as a pointer to the base class, it is required. So when pointers to the base class are loaded from an archive, the
   archive creates an object of the correct class. */
BOOST_CLASS_EXPORT_GUID(GameObject, "GameObject")

/** A pseudo derived game object.
 * This is an example for a derived class.
 */
class Windmill : public GameObject {
public:
  Windmill() {
    cerr << "created a Windmill " << this << endl;
  }
  
  void setRotationAngle(float angle) {
    __angle = angle;
  }

  void setRotationSpeed(float speed) {
    __speed = speed;
  }
  
  float getRotationAngle() const {
    return __angle;
  }
  
  float getRotationSpeed() const {
    return __speed;
  }
  
private:
  friend class boost::serialization::access;
  
  template<class Archive>
  void serialize(Archive & ar, const unsigned int version) {
    /* we must explicitly serialize the base object. for XML support,
       we must also provide a name for it. */
    ar & boost::serialization::make_nvp("GameObject", boost::serialization::base_object<GameObject>(*this));
    
    ar & boost::serialization::make_nvp("angle", __angle);
    ar & boost::serialization::make_nvp("speed", __speed);
  }
  
private:
  float __angle;
  float __speed;
};

BOOST_CLASS_EXPORT_GUID(Windmill,   "Windmill")

/** A pseudo derived game object referencing another game object.  In
 * our example, a Windmill door will point to a Windmill which is also
 * contained in the scene.  The serialization engine of BOOST will
 * store the Windmill only once in the archive. When the scene is
 * loaded again, only one Windmill will be created and added to the
 * scene, and the WindmillDoor will point to it. This shows that BOOST
 * can serialize arbitrary graphs of objects that are pointing to each
 * other.
 *
 * To make it more difficult for BOOST, we add first the WindmillDoor
 * to the scene and then the Windmill.  In fact it doesn't make a
 * difference, but it is interesting how it looks like in the archive
 * file (see the XML output).
 */
class WindmillDoor : public GameObject {
public:
  WindmillDoor()
    : __is_opened(false),
      __windmill(0)
  {
    cerr << "created a WindmillDoor " << this << endl;
  }
  
  void setOpened(bool opened) {
    __is_opened = opened;
  }
  
  void setWindmill(Windmill* windmill) {
    __windmill = windmill;
  }
  
  bool isOpened() const {
    return __is_opened;
  }
  
  Windmill* getWindmill() const {
    return __windmill;
  }
  
private:
  friend class boost::serialization::access;
  
  template<class Archive>
  void serialize(Archive & ar, const unsigned int version) {
    /* NEVER forget to serialize the base object! */
    ar & boost::serialization::make_nvp("GameObject", boost::serialization::base_object<GameObject>(*this));
    
    /* see how bools look like. They are serialized as 0 and 1 in XML... */
    ar & boost::serialization::make_nvp("is_opened", __is_opened);
    
    /* and here is the reference */
    ar & boost::serialization::make_nvp("windmill", __windmill);
  }
  
private:
  bool __is_opened;
  Windmill* __windmill;
};

BOOST_CLASS_EXPORT_GUID(WindmillDoor,   "WindmillDoor")

/** A container for game objects.  This class shows that BOOST can
 * serialize STL lists, vectors and other containers containing
 * pointers to object.  It should also be possible to serialize
 * user-defined container classes.
 */
class Scene {
public:
  Scene() {
    cerr << "created a Scene " << this << endl;
  }
  
  virtual ~Scene() {
    while(!__objects.empty()) {
      delete __objects.front();
      __objects.pop_front();
    }
  }
  
  void addObject(GameObject* object) {
    __objects.push_back(object);
  }
  
private:
  friend class boost::serialization::access;
  
  template<class Archive>
  void serialize(Archive & ar, const unsigned int version) {
    ar & boost::serialization::make_nvp("objects", __objects);
  }
  
private:
  list<GameObject*> __objects;
};


void saveGame() {
  /* create and open an XML archive for output */
  std::ofstream ofs("filename.xml");
  boost::archive::xml_oarchive oa(ofs);
  
  /* create a scene */
  Scene scene;
  
  /* create class instance */
  GameObject* object1 = new GameObject();
  scene.addObject(object1);
  object1->setName("KarlHeinz");
  object1->setPosition(Vector(1,2,3));

  /* create another class instance */
  WindmillDoor* object3 = new WindmillDoor();
  scene.addObject(object3);
  object3->setName("Tor");
  object3->setPosition(Vector(3,2,1));
  object3->setOpened(true);
  
  /* create another class instance */
  Windmill* object2 = new Windmill();
  scene.addObject(object2);
  object2->setName("Muehle1");
  object2->setPosition(Vector(3,2,1));
  object2->setRotationAngle(20.0f);
  object2->setRotationSpeed(0.1f);
  
  /* add a forward reference */
  object3->setWindmill(object2);
  
  /* write class instance to archive */
  oa << boost::serialization::make_nvp("scene", scene);
}

void loadGame() {
  /* create and open an archive for input */
  std::ifstream ifs("filename.xml", std::ios::binary);
  boost::archive::xml_iarchive ia(ifs);
  
  /* create a scene */
  Scene scene;
  
  /* read class state from archive */
  ia >> boost::serialization::make_nvp("scene", scene);
  
  ifs.close();
}

int main() {
  cerr << "saving game state" << endl;
  saveGame();
  
  cerr << "loading game state" << endl;
  loadGame();
  return 0;
}
