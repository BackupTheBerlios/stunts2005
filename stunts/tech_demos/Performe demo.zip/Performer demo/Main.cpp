// Main.cpp: Implementierung der Klasse Main.
//
//////////////////////////////////////////////////////////////////////

#include "Main.h"

#include <iostream.h> 
#include <stdlib.h> 
#include <Performer/pf.h> 
#include <Performer/pf/pfChannel.h> 
#include <Performer/pf/pfNode.h> 
#include <Performer/pf/pfScene.h> 
#include <Performer/pf/pfDCS.h> 
#include <Performer/pf/pfGeode.h> 
#include <Performer/pf/pfLightSource.h> 
#include <Performer/pfutil.h> 
#include <Performer/pfdu.h> 
#include <Performer/pfui.h> 
#include <Performer/pfui/pfiXformer.h>

//////////////////////////////////////////////////////////////////////
// Konstruktion/Destruktion
//////////////////////////////////////////////////////////////////////

Main::Main()
{

}

Main::~Main()
{

}

pfiTDFXformer* xformer = NULL; 
bool exitNow = false; 
pfuEventStream events;

void handleEvents(void)
{
	pfuGetEvents(&events);

	for (int j=0; j < events.numDevs; ++j)
	{
		int dev = events.devQ[j];
		if ( events.devCount[dev] > 0)
		{
			switch ( dev )
			{
				case PFUDEV_WINQUIT:
					exitNow = true;
					events.devCount[dev] = 0;
					break;

				case PFUDEV_KEYBD: {
					for (int i=0; i < events.numKeys; ++i )
					{
						int key = events.keyQ[i];
						if ( events.keyCount[key] )
						{
							switch (key)
							{
								case 27:
									exitNow = true;
									break;
								case 'r':
									xformer->stop(); 
									xformer->reset();
									break;
								default:
									break;
							}
							//end switch
						}
						//end if
					}
					//end for 
					}

					events.devCount[dev] = 0;
					break;

					case PFUDEV_REDRAW:
						events.devCount[dev] = 0;
						break;
					
					default:
						break;
			}
			//end switch
		}
		//end if
	}
	//end for

	events.numKeys = 0;
	events.numDevs = 0;
}

int main(int argc, char **argv)
{

	pfInitArenas();


	// Initialize Performer
	pfInit();
	pfuInitUtil();
	pfiInit();
	pfMultiprocess( PFMP_APPCULLDRAW );
	

	// Load all loader dlls before pfConfig() forks
	pfdInitConverter("esprit.pfb");

	pfConfig();

	// Append pfFilePath to Performers search path
	pfFilePath("C:\\Programme\\OpenGL Performer\\Data");

	// Load file "esprit.pfb"
	pfNode *root = pfdLoadFile("esprit.pfb");	

	if (root == NULL)
	{ 
		pfExit();
		return(-1);
	}
	//end if


	// Determine extent of scenes geometry
	pfSphere bsphere;
	root->getBound(&bsphere);

	// Instancing the pfScene
	pfScene* scene =new pfScene;

	// Adding a default LightSource
	scene->addChild(new pfLightSource);

	// Recenter the model to the origin using a pfMatrix
	pfMatrix transfo;

	transfo.makeTrans(-bsphere.center[PF_X], 
						-bsphere.center[PF_Y], 
						-bsphere.center[PF_Z]);

	pfMatrix mscale;
	float scal = 1./bsphere.radius;
	mscale.makeScale(scal, scal, scal);
	transfo = transfo + mscale; 
	pfSCS* recenter = new pfSCS(transfo); 
	recenter->addChild(root); 
	recenter->flatten(0); 
	recenter->getBound(&bsphere);
	
	// Adding a DCS for trackball movement
	pfGroup* group = new pfGroup; 
	group->addChild(recenter); 
	pfDCS* dcs = new pfDCS; 
	dcs->addChild(group); 
	scene->addChild(dcs);


	// Configure and open window
	pfPipe *p = pfGetPipe(0); 
	pfPipeWindow *pw = new pfPipeWindow(p); 
	pw->setWinType(PFPWIN_TYPE_X); 
	pfuInitInput(pw, PFUINPUT_NOFORK_X); 
	pw->setName("Esprit"); 
	pw->setOriginSize(30,30,500,500); 
	pw->open();


	// Create and configure channel
	pfChannel* chan = new pfChannel(p); 
	chan->setScene(scene); 
	chan->setFOV(45.0f, 0.0f); 
	chan->setNearFar(0.1f, 100.0f * bsphere.radius); 
	chan->setLODAttr(PFLOD_SCALE,2.15f); 
	chan->setLODAttr(PFLOD_FADE,1.0f);

	// Init a position
	pfCoord view; 
	view.xyz.copy(bsphere.center); 
	view.xyz[PF_Y] -= 2.*bsphere.radius; 
	view.hpr.set(0.0f,0.0f,0.0f); 
	chan->setView(view.xyz, view.hpr);

	// Trackball ...
	pfuMouse mouse; 
	xformer = new pfiTDFXformer; 
	xformer->setAutoInput(chan, &mouse, &events); 
	xformer->setAutoPosition(chan, dcs); 
	xformer->selectModel(PFITDF_TRACKBALL); 
	xformer->setNode(group); 
	xformer->setCoord(&view); 
	xformer->setResetCoord(&view);

	
	while(!exitNow)
	{
		pfuGetMouse(&mouse);
		xformer->update();

		pfSync();

		pfFrame();

		handleEvents();
	}
	//end while

	pfuExitInput();
	pfuExitUtil();
	pfExit();

	return 0;
}