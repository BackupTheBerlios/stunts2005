// Main.h: Schnittstelle f�r die Klasse Main.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MAIN_H__4D41B547_4E81_43E1_BEA8_4D79E078AEA5__INCLUDED_)
#define AFX_MAIN_H__4D41B547_4E81_43E1_BEA8_4D79E078AEA5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class Main  
{
public:
	Main();
	virtual ~Main();

};

#endif // !defined(AFX_MAIN_H__4D41B547_4E81_43E1_BEA8_4D79E078AEA5__INCLUDED_)
